﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Data;
using Microsoft.Win32;
using builder.Models;
using builder.Settings;
using builder.Viewport;
using ControlzEx.Theming;
using OpenTK.Mathematics;

namespace builder;

public partial class MainWindow : Fluent.RibbonWindow
{
    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out WinPoint lpPoint);
    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int X, int Y);

    [StructLayout(LayoutKind.Sequential)]
    private struct WinPoint { public int X; public int Y; }

    private readonly StudioScene _scene = new();
    private readonly Physics.PhysicsWorld _physics = new();
    private bool _sceneReady;
    private string _tool = "Move";

    private GridLength _leftWidth = new(260);
    private GridLength _rightWidth = new(300);
    private DateTime _lastFpsPush = DateTime.MinValue;
    private bool _glStarted;
    private TimeSpan? _lastPumpTime;

    // GL renders into a shared texture presented by WPF's compositor. The
    // compositor already provides display-paced, tear-free presentation; a
    // second software limiter causes uneven frame pacing.
    private bool _vsync = true;
    private double _refreshHz = 60; // measured from compositor ticks
    private TimeSpan? _lastTick;

    // On-demand rendering: input handlers set _needsFrame; idle ticks skip GL work.
    private bool _needsFrame = true;
    private DateTime _lastFrameUtc;
    private DateTime _lastPropPush = DateTime.MinValue;

    private Point _lastMouse;
    private bool _lookHeld; // right button: locked-cursor look
    private bool _panHeld;  // middle button: pan
    private bool _orbitHeld; // play mode: left/right drag orbits the follow camera

    private string? _faceOpenPath; // experimental avatar face (Faces/face.png next to the exe)
    private string? _faceBlinkPath;
    private DateTime _playStartUtc;
    private int _dragAxis = -1; // gizmo handle being dragged (0=X,1=Y,2=Z)
    private bool _objectDrag;
    private Vector3 _objectDragOffset;
    private Vector3 _dragOffset = Vector3.Zero; // move-grab offset along the axis
    private Vector3 _dragSize;   // scale-grab object size
    private float _dragCoord0;   // scale-grab axis coordinate
    private float _dragSign = 1f; // scale-grab side (+1/-1 end of the axis)
    private float _scaleRawS;    // latest raw axis coordinate from the mouse
    private float _smoothS;      // eased coordinate actually applied to the size
    private TimeSpan? _prevPumpTime; // for frame-rate independent easing
    private Vector3 _dragR0;     // rotate-grab radial vector (plane point minus center)

    private SettingsWindow? _settingsWin;
    private Rect _winBounds;
    private bool _winBoundsSaved;

    private ObservableCollection<SceneNode> _explorerRoots = new();
    private SceneNode _workspace = new();
    private Viewport.SceneObject? _liveObj; // object shown in Properties
    private List<PropertyRow>? _liveRows;   // updated in place (no rebind) during drags
    private string? _liveService; // "Sun" | "Atmosphere" | "Lighting" when a service node is shown
    private List<PropertyRow> _propFull = new(); // unfiltered rows for the filter box
    private bool _propFilterSync; // guard: filter rebind vs slider/commit events
    private bool _customSync; // guard: wheel <-> brightness <-> hex updates
    private double _customH, _customS = 1, _customV = 1; // custom color, HSV
    private int _partCounter;
    private static readonly Color4[] Palette =
    {
        new(0.25f, 0.55f, 0.95f, 1f), // blue
        new(0.95f, 0.55f, 0.20f, 1f), // orange
        new(0.30f, 0.80f, 0.35f, 1f), // green
        new(0.70f, 0.40f, 0.90f, 1f), // purple
        new(0.95f, 0.30f, 0.30f, 1f), // red
        new(0.25f, 0.85f, 0.85f, 1f), // teal
    };

    public MainWindow()
    {
        CrashLog.Startup("MainWindow ctor begin");
        InitializeComponent();
        CrashLog.Startup("InitializeComponent done");
        ApplyAllSettings();
        TimeSlider.Value = AppSettings.Current.TimeOfDay; // handler syncs scene + label

        _explorerRoots = SceneNode.CreateDefaultWorkspace();
        _workspace = _explorerRoots.First(r => r.Name == "Workspace");
        ExplorerTree.ItemsSource = _explorerRoots;
        RefreshExplorer();
        SetPropertyRows(DefaultProperties("Workspace", "Workspace"));
        BuildSwatches();
        BuildWheel();
        BuildMaterials();

        // Roblox-Studio-style camera input on the viewport.
        ViewportControl.PreviewMouseDown += Viewport_MouseDown;
        ViewportControl.PreviewMouseMove += Viewport_MouseMove;
        ViewportControl.PreviewMouseUp += Viewport_MouseUp;
        ViewportControl.MouseWheel += Viewport_Wheel;
        ViewportControl.PreviewKeyDown += Viewport_KeyDown;
        PreviewKeyDown += MainWindow_PreviewKeyDown; // Esc exits borderless
        // Safety: never leave the cursor hidden / drag stuck (Alt-Tab, focus loss...).
        ViewportControl.LostKeyboardFocus += (_, _) => CancelCameraDrag();
        ViewportControl.LostMouseCapture += (_, _) => CancelCameraDrag();

        // Start GL here (not in Loaded): GLWpfControl only hooks CompositionTarget.Rendering
        // on IsVisibleChanged *after* Start(). Starting in Loaded misses that event,
        // so RenderContinuously never invalidates -> updates only on resize.
        // Default is 4.0 (works everywhere); 4.6 is opt-in via Settings.
        // A GLWpfControl can only Start() once, so a failed 4.6 saves 4.0 and
        // restarts the app instead of retrying in place.
        var gl = AppSettings.Current;
        CrashLog.Startup($"GL start begin ({gl.GlMajor}.{gl.GlMinor})");
        if (!TryStartGL(gl.GlMajor, gl.GlMinor) && gl.GlMajor == 4 && gl.GlMinor == 6)
        {
            CrashLog.Startup("GL 4.6 failed, showing fallback prompt");
            // No Owner: this window isn't shown yet and WPF forbids an unshown owner.
            // (CenterOwner without an owner centers on screen.)
            var fallback = new RenderFallbackWindow();
            if (fallback.ShowDialog() == true)
            {
                CrashLog.Startup("fallback accepted, saving 4.0 and restarting");
                AppSettings.Current.GlMajor = 4;
                AppSettings.Current.GlMinor = 0;
                AppSettings.Current.Save();
                MessageBox.Show("builder will now restart to switch the rendering system to OpenGL 4.",
                    "builder engine", MessageBoxButton.OK, MessageBoxImage.Information);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = Environment.ProcessPath,
                    UseShellExecute = true,
                });
                Application.Current.Shutdown();
                return;
            }
            else CrashLog.Startup("fallback declined");
        }
        CrashLog.Startup($"GL started={_glStarted}");
        if (!_glStarted)
        {
            StatusText.Text = "Viewport unavailable: no supported OpenGL context.";
            ViewportTitle.Text = "Viewport unavailable";
            ToolLabel.Text = "Rendering system failed to start — see Output.";
        }

        // Belt-and-suspenders pump: guarantees a render every vsync even if the
        // control's internal CompositionTarget subscription missed (the resize-only bug).
        CompositionTarget.Rendering += PumpViewport;
        Closing += OnClosing;
        Loaded += async (_, _) => await CheckForUpdatesAsync(); // daily GitHub check, silent unless newer
        _dirty = false; // startup itself must not count as an edit
        UpdateTitle();
        UpdateUndoButtons();
        CrashLog.Startup("MainWindow ctor end");
    }

    /// <summary>Start the GL viewport at a fixed version. False = unsupported here.</summary>
    private bool TryStartGL(int major, int minor)
    {
        try
        {
            var settings = ViewportControl.Settings?.Clone() ?? new OpenTK.Wpf.GLWpfControlSettings();
            settings.MajorVersion = major;
            settings.MinorVersion = minor;
            settings.RenderContinuously = true;
            settings.Samples = AppSettings.Current.Msaa ? 4 : 0; // MSAA: renderer auto-resolves
            ViewportControl.Start(settings);
            _glStarted = true;
            StudioScene.GlslVersion = major * 100 + minor * 10; // 460 / 400
            Log($"GLWpfControl started (OpenGL {major}.{minor}).");
            return true;
        }
        catch (Exception ex)
        {
            Log($"Viewport start failed (OpenGL {major}.{minor}): " + ex.Message);
            StatusText.Text = $"Viewport failed (OpenGL {major}.{minor}): " + ex.Message;
            return false;
        }
    }

    /// <summary>TEMPORARY testing hook: force-show the fallback prompt. Pure UI
    /// test — changes nothing (no save, no GL restart).</summary>
    public void TestFallbackPrompt()
    {
        var fallback = new RenderFallbackWindow { Owner = this };
        bool accepted = fallback.ShowDialog() == true;
        Log($"Fallback prompt test: {(accepted ? "OK" : "Cancel")}.");
        StatusText.Text = $"Fallback test: {(accepted ? "OK" : "Cancel")}";
    }

    // ---------- auto-update (GitHub Releases) ----------
    //
    // Release convention the updater expects: a tag like v0.2.0 with a
    // self-contained win-x64 zip attached (ideally named *win-x64*.zip).
    // Publish via the Windows-x64 profile, zip the folder, attach, done.

    /// <summary>Parse a release tag ("v0.2.0", "1.2", "0.3.0-beta") into a Version.</summary>
    public static bool TryParseUpdateVersion(string? tag, out Version? version)
    {
        version = null;
        if (string.IsNullOrWhiteSpace(tag)) return false;
        string t = tag.Trim().TrimStart('v', 'V');
        int cut = t.IndexOfAny(new[] { '-', '+' }); // strip pre-release/build metadata
        if (cut >= 0) t = t[..cut];
        if (!Version.TryParse(t, out var v)) return false;
        version = v;
        return true;
    }

    /// <summary>Pick the win-x64 zip download URL from a release assets array.</summary>
    public static string? PickUpdateAsset(System.Text.Json.JsonElement assets)
    {
        string? fallback = null;
        foreach (var a in assets.EnumerateArray())
        {
            if (!a.TryGetProperty("name", out var n) || !a.TryGetProperty("browser_download_url", out var u))
                continue;
            string? name = n.GetString(), url = u.GetString();
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(url)) continue;
            if (!name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) continue;
            fallback ??= url;
            if (name.Contains("win-x64", StringComparison.OrdinalIgnoreCase)) return url;
        }
        return fallback;
    }

    /// <summary>Manual trigger for the Settings "Check now" button (fire-and-forget).</summary>
    public void CheckForUpdatesNow() => _ = CheckForUpdatesAsync(manual: true);

    private async Task CheckForUpdatesAsync(bool manual = false)
    {
        string repo = (AppSettings.Current.UpdateRepo ?? "").Trim().Trim('/');
        if (!manual && !AppSettings.Current.CheckForUpdates) return;
        if (string.IsNullOrWhiteSpace(repo) || !repo.Contains('/'))
        {
            if (manual)
            {
                Log("Updates: set the GitHub repo (owner/name) in Settings first.");
                StatusText.Text = "Set update repo first";
            }
            return;
        }
        if (!manual && (DateTime.UtcNow - AppSettings.Current.LastUpdateCheckUtc).TotalHours < 24) return;
        AppSettings.Current.LastUpdateCheckUtc = DateTime.UtcNow;
        AppSettings.Current.Save();
        try
        {
            using var http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("builder-updater");
            string json = await http.GetStringAsync($"https://api.github.com/repos/{repo}/releases/latest");
            using var doc = System.Text.Json.JsonDocument.Parse(json);
            var root = doc.RootElement;
            string? tag = root.TryGetProperty("tag_name", out var tp) ? tp.GetString() : null;
            if (!TryParseUpdateVersion(tag, out var latest) || latest == null)
            {
                Log($"Updates: couldn't read latest version (tag '{tag}').");
                return;
            }
            var current = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            if (current != null && latest <= current)
            {
                if (manual)
                {
                    Log($"Updates: already on latest ({current}).");
                    StatusText.Text = "Already up to date";
                }
                return;
            }
            string notes = root.TryGetProperty("body", out var bp) ? (bp.GetString() ?? "") : "";
            if (notes.Length > 400) notes = notes[..400] + "…";
            string? assetUrl = root.TryGetProperty("assets", out var ap) ? PickUpdateAsset(ap) : null;
            if (assetUrl == null)
            {
                Log($"Updates: {tag} has no downloadable zip.");
                StatusText.Text = "Update has no download";
                return;
            }
            var confirm = new ConfirmWindow { Owner = this };
            confirm.Message = $"builder {latest} is available (you have {current}). Update now? The app will restart."
                + (string.IsNullOrWhiteSpace(notes) ? "" : $"\n\n{notes}");
            if (confirm.ShowDialog() != true)
            {
                Log($"Updates: skipped {tag}.");
                return;
            }
            await DownloadAndApplyAsync(assetUrl, latest.ToString());
        }
        catch (Exception ex)
        {
            Log("Update check failed: " + ex.Message);
            if (manual) StatusText.Text = "Update check failed";
        }
    }

    private async Task DownloadAndApplyAsync(string url, string version)
    {
        StatusText.Text = $"Downloading builder {version}...";
        Log($"Updates: downloading {version}.");
        string tmp = Path.Combine(Path.GetTempPath(), "builder-update", version);
        Directory.CreateDirectory(tmp);
        string zip = Path.Combine(tmp, "update.zip");
        using (var http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromMinutes(10) })
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("builder-updater");
            using var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            resp.EnsureSuccessStatusCode();
            await using var fs = File.Create(zip);
            await (await resp.Content.ReadAsStreamAsync()).CopyToAsync(fs);
        }
        string stage = Path.Combine(tmp, "app");
        if (Directory.Exists(stage)) Directory.Delete(stage, true);
        System.IO.Compression.ZipFile.ExtractToDirectory(zip, stage);
        // The running exe can't overwrite itself: a helper batch waits for this
        // process to exit, mirrors the staging dir over the app dir, restarts.
        string exe = Path.Combine(AppContext.BaseDirectory, "builder.exe");
        string bat = Path.Combine(tmp, "apply.bat");
        int pid = Environment.ProcessId;
        File.WriteAllText(bat,
            "@echo off\r\n" +
            $":wait\r\ntasklist /FI \"PID eq {pid}\" 2>NUL | find \"{pid}\" >NUL\r\n" +
            "if not errorlevel 1 (timeout /t 1 /nobreak >NUL & goto wait)\r\n" +
            $"xcopy \"{stage}\\*\" \"{AppContext.BaseDirectory}\" /E /Y /Q\r\n" +
            $"start \"\" \"{exe}\"\r\n" +
            $"rmdir /S /Q \"{tmp}\"\r\n");
        Log($"Updates: {version} staged, restarting to apply.");
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
        {
            FileName = bat,
            UseShellExecute = true,
            CreateNoWindow = true,
        });
        Application.Current.Shutdown();
    }

    private void OnClosing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        var confirm = new ConfirmWindow { Owner = this };
        if (_dirty) confirm.Message = "Are you sure you want to exit builder? Any unsaved changes will be lost 💀😭🥺"; // Discard unsaved changes and exit?
        if (confirm.ShowDialog() != true)
        {
            e.Cancel = true;
            return;
        }
        _settingsWin?.CloseImmediate(); // no farewell animation on app exit
        CompositionTarget.Rendering -= PumpViewport;
        _physics.Dispose();
        _scene.Dispose();
    }

    private void PumpViewport(object? sender, EventArgs e)
    {
        if (!_glStarted || !ViewportControl.IsVisible) return;
        if (e is not RenderingEventArgs re) return;
        if (re.RenderingTime == _lastPumpTime) return; // same-frame duplicate
        _lastPumpTime = re.RenderingTime;
        double pumpDt = _prevPumpTime.HasValue
            ? Math.Clamp((re.RenderingTime - _prevPumpTime.Value).TotalSeconds, 0, 0.1)
            : 0.016;
        _prevPumpTime = re.RenderingTime;

        // Measure the display rate from every compositor tick (compositor clock).
        if (_lastTick.HasValue)
        {
            double interval = (re.RenderingTime - _lastTick.Value).TotalSeconds;
            if (interval > 0.0005 && interval < 0.5)
                _refreshHz += (1.0 / interval - _refreshHz) * 0.05;
        }
        _lastTick = re.RenderingTime;

        // Poll WASD/QE every tick while the viewport has keyboard focus.
        // No mouse button needed: click the viewport once, then fly with keys.
        // In play mode the same keys drive the avatar instead (camera-relative).
        if (_physics.Simulating && _physics.Player != null)
        {
            if (ViewportControl.IsKeyboardFocused)
            {
                _physics.PlayerMoveX = (Keyboard.IsKeyDown(Key.D) ? 1 : 0) - (Keyboard.IsKeyDown(Key.A) ? 1 : 0);
                _physics.PlayerMoveZ = (Keyboard.IsKeyDown(Key.W) ? 1 : 0) - (Keyboard.IsKeyDown(Key.S) ? 1 : 0);
                _physics.PlayerCamYaw = _scene.Yaw;
                _physics.JumpHeld = Keyboard.IsKeyDown(Key.Space);
            }
            else
            {
                _physics.PlayerMoveX = 0;
                _physics.PlayerMoveZ = 0;
                _physics.JumpHeld = false;
            }
            // Experimental avatar face: blink every few seconds on the face panel.
            var faceObj = _physics.FaceObject;
            if (_faceOpenPath != null && _faceBlinkPath != null && faceObj != null && faceObj.Decals.Count > 0 &&
                (faceObj.Decals[0].Image == _faceOpenPath || faceObj.Decals[0].Image == _faceBlinkPath))
            {
                bool closed = (DateTime.UtcNow - _playStartUtc).TotalSeconds % 3.4 < 0.15;
                faceObj.Decals[0].Image = closed ? _faceBlinkPath : _faceOpenPath;
            }
            _scene.FlyInput = Vector3.Zero;
            _scene.FlySlow = false;
        }
        else if (ViewportControl.IsKeyboardFocused)
        {
            float x = (Keyboard.IsKeyDown(Key.D) ? 1 : 0) - (Keyboard.IsKeyDown(Key.A) ? 1 : 0);
            float y = (Keyboard.IsKeyDown(Key.E) ? 1 : 0) - (Keyboard.IsKeyDown(Key.Q) ? 1 : 0);
            float z = (Keyboard.IsKeyDown(Key.W) ? 1 : 0) - (Keyboard.IsKeyDown(Key.S) ? 1 : 0);
            _scene.FlyInput = new Vector3(x, y, z);
            _scene.FlySlow = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);
        }
        else
        {
            _scene.FlyInput = Vector3.Zero;
            _scene.FlySlow = false;
        }

        // Render on demand: physics, motion, or an explicit kick. The 500 ms net
        // guarantees recovery if any input ever forgets to kick a frame.
        var nowUtc = DateTime.UtcNow;
        bool animate = _physics.Simulating || !_scene.IsIdle || _needsFrame ||
            (nowUtc - _lastFrameUtc).TotalMilliseconds > 500;
        _needsFrame = false;
        if (!animate) return;

        // Ease an active scale drag toward the latest mouse target, then apply.
        // Runs per presented frame so motion stays smooth even between mouse events.
        if (_dragAxis >= 0 && _scene.ActiveGizmo == GizmoKind.Scale && _scene.Selected != null)
        {
            float t = 1f - MathF.Exp(-_scene.ScaleResponsiveness * (float)pumpDt);
            _smoothS += (_scaleRawS - _smoothS) * t;
            ApplyScaleSize(_smoothS);
        }

        _physics.Step(_scene); // fixed-step bodies -> scene poses (no-op unless playing)
        if (_physics.Simulating) _scene.InvalidateShadows(); // bodies move every step
        _lastFrameUtc = nowUtc;
        ViewportControl.InvalidateVisual();
    }

    // ---------- viewport (OpenTK) ----------

    private void Viewport_Render(TimeSpan delta)
    {
        if (!_sceneReady)
        {
            try
            {
                _scene.Initialize();
                _sceneReady = true;
                _partCounter = _scene.Objects.Count;
                RefreshExplorer();
                if (_scene.Selected != null)
                {
                    ExplorerTree.UpdateLayout();
                    SelectNodeRecursive(ExplorerTree, _scene.Selected);
                }
                SyncAnchorToggle(); // initial selection (Part, unanchored)
                Log($"Scene ready: {_scene.Objects.Count} objects.");
                if (!string.IsNullOrWhiteSpace(_scene.InitLog))
                    Log("GL shaders:\n" + _scene.InitLog.TrimEnd());
            }
            catch (Exception ex)
            {
                Log("Scene init failed: " + ex.Message);
                return;
            }
        }

        int w = ViewportControl.FrameBufferWidth;
        int h = ViewportControl.FrameBufferHeight;
        if (w <= 0 || h <= 0)
        {
            w = Math.Max(1, (int)ViewportControl.ActualWidth);
            h = Math.Max(1, (int)ViewportControl.ActualHeight);
        }
        _scene.Render(w, h);

        // throttle WPF text updates (keeps text crisp, avoids layout churn)
        var now = DateTime.UtcNow;
        if ((now - _lastFpsPush).TotalMilliseconds > 250)
        {
            _lastFpsPush = now;
            var p = _scene.Position;
            FpsLabel.Text = $"{_scene.Fps:0} FPS · {_scene.CpuMs:0.0}ms";
            CamText.Text = $"Pos {p.X:0.0},{p.Y:0.0},{p.Z:0.0} yaw {_scene.Yaw:0}° pitch {_scene.Pitch:0}°";
        }
    }

    private void Viewport_MouseDown(object sender, MouseButtonEventArgs e)
    {
        ViewportControl.Focus();
        _needsFrame = true; // any press may change the view or selection
        _lastMouse = e.GetPosition(ViewportControl);
        if (_physics.Simulating && _physics.Player != null)
        {
            // Play mode: RIGHT locks the cursor and turns FPS-style (like Roblox
            // right-drag and edit-mode look). LEFT click-selects and drag-orbits
            // with a free cursor. Gizmo grabs stay off.
            if (e.RightButton == MouseButtonState.Pressed)
            {
                _lookHeld = true;
                ViewportControl.Cursor = Cursors.None;
                var c = ViewportCenterScreen();
                SetCursorPos((int)c.X, (int)c.Y);
                ViewportControl.CaptureMouse();
                return;
            }
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                var mp = e.GetPosition(ViewportControl);
                float w = (float)ViewportControl.ActualWidth;
                float h = (float)ViewportControl.ActualHeight;
                SelectObject(w > 0 && h > 0 ? _scene.Pick((float)mp.X, (float)mp.Y, w, h) : null);
                _orbitHeld = true;
                ViewportControl.CaptureMouse();
            }
            return;
        }
        if (e.RightButton == MouseButtonState.Pressed)
        {
            _lookHeld = true;
            // FPS-style cursor lock: hide the cursor and pin it to the viewport
            // center so turning never hits a screen edge.
            ViewportControl.Cursor = Cursors.None;
            var c = ViewportCenterScreen();
            SetCursorPos((int)c.X, (int)c.Y);
        }
        if (e.MiddleButton == MouseButtonState.Pressed) _panHeld = true;
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            var mp = e.GetPosition(ViewportControl);
            float w = (float)ViewportControl.ActualWidth;
            float h = (float)ViewportControl.ActualHeight;
            int axis;
            Vector3 ringHit = Vector3.Zero;
            if (_scene.ActiveGizmo == GizmoKind.None) axis = -1;
            else if (_scene.ActiveGizmo == GizmoKind.Rotate)
                axis = _scene.PickRingAxis((float)mp.X, (float)mp.Y, w, h, FrameH(), out ringHit);
            else
                axis = _scene.PickGizmoAxis((float)mp.X, (float)mp.Y, w, h, FrameH());
            if (axis >= 0 && _scene.Selected != null)
            {
                // Grabbed a gizmo handle: snapshot for move (offset), scale (size + coord),
                // rotate (radial vector on the ring plane).
                _dragAxis = axis;
                _dragBefore = CaptureState("Drag " + _tool);
                _dragMoved = false;
                _scene.ActiveAxis = axis;
                _scene.GetPickRay((float)mp.X, (float)mp.Y, w, h, out var ro, out var rd);
                var grabPoint = _scene.AxisPoint(axis, ro, rd);
                _dragOffset = _scene.Selected.Position - grabPoint;
                _dragSize = _scene.Selected.Size;
                _dragCoord0 = Vector3.Dot(grabPoint - _scene.Selected.Position,
                    _scene.GizmoAxis(axis));
                _dragSign = Math.Sign(Vector3.Dot(grabPoint - _scene.Selected.Position,
                    _scene.GizmoAxis(axis)));
                if (_dragSign == 0) _dragSign = 1;
                _scaleRawS = _smoothS = _dragCoord0; // eased sizing starts exactly at grab
                _dragR0 = _scene.ActiveGizmo == GizmoKind.Rotate
                    ? ringHit - _scene.Selected.Position
                    : Vector3.Zero;
            }
            else
            {
                // Click empty space: select the part under the cursor (or deselect).
                var picked = _scene.Pick((float)mp.X, (float)mp.Y, w, h);
                bool beginObjectDrag = _tool == "Move" && picked != null &&
                    ReferenceEquals(picked, _scene.Selected);
                SelectObject(picked);
                if (beginObjectDrag && picked != null)
                {
                    _scene.GetPickRay((float)mp.X, (float)mp.Y, w, h, out var ro, out var rd);
                    if (TryPlacementSurface(picked, ro, rd, out var grabPoint, out var grabNormal))
                    {
                        _objectDrag = true;
                        _dragBefore = CaptureState("Drag " + _tool);
                        _dragMoved = false;
                        var half = picked.Size * 0.5f;
                        var clearance = MathF.Abs(grabNormal.X) * half.X +
                            MathF.Abs(grabNormal.Y) * half.Y + MathF.Abs(grabNormal.Z) * half.Z;
                        _objectDragOffset = picked.Position - (grabPoint + grabNormal * clearance);
                    }
                }
            }
        }
        if (_lookHeld || _panHeld || _dragAxis >= 0 || _objectDrag) ViewportControl.CaptureMouse();
    }

    /// <summary>Framebuffer height in px (DPI-aware), for gizmo-size matching.</summary>
    private float FrameH()
    {
        return ViewportControl.FrameBufferHeight > 0
            ? ViewportControl.FrameBufferHeight
            : Math.Max(1, (int)ViewportControl.ActualHeight);
    }

    private void Viewport_MouseMove(object sender, MouseEventArgs e)
    {
        if (_orbitHeld)
        {
            // Play-mode orbit: plain deltas, no cursor warp (unlike FPS look).
            var p = e.GetPosition(ViewportControl);
            float dx = (float)(p.X - _lastMouse.X);
            float dy = (float)(p.Y - _lastMouse.Y);
            _lastMouse = p;
            _scene.Look(dx, dy);
            _needsFrame = true;
            return;
        }
        if (_objectDrag && _scene.Selected != null)
        {
            _dragMoved = true;
            var mp = e.GetPosition(ViewportControl);
            float w = (float)ViewportControl.ActualWidth;
            float h = (float)ViewportControl.ActualHeight;
            _scene.GetPickRay((float)mp.X, (float)mp.Y, w, h, out var ro, out var rd);
            if (!TryPlacementSurface(_scene.Selected, ro, rd, out var point, out var normal))
                TryRayPlane(ro, rd, _scene.Selected.Position, _scene.Forward, out point);
            if (point != Vector3.Zero)
            {
                var half = _scene.Selected.Size * 0.5f;
                var clearance = MathF.Abs(normal.X) * half.X +
                    MathF.Abs(normal.Y) * half.Y + MathF.Abs(normal.Z) * half.Z;
                var np = point + normal * clearance + _objectDragOffset;
                if (SnapCheck.IsChecked == true)
                    np = new Vector3(MathF.Round(np.X), MathF.Round(np.Y), MathF.Round(np.Z));
                np = ConstrainDragPosition(_scene.Selected, np);
                _scene.Selected.Position = np;
                if (_physics.Simulating) _physics.Teleport(_scene.Selected);
                UpdateLivePropsThrottled();
                _scene.InvalidateShadows();
                _needsFrame = true;
            }
            return;
        }
        if (_dragAxis >= 0 && _scene.Selected != null)
        {
            _dragMoved = true;
            var mp = e.GetPosition(ViewportControl);
            float w = (float)ViewportControl.ActualWidth;
            float h = (float)ViewportControl.ActualHeight;
            _scene.GetPickRay((float)mp.X, (float)mp.Y, w, h, out var ro, out var rd);
            if (_scene.ActiveGizmo == GizmoKind.Rotate)
            {
                // Rotate about the ring's world axis by the swept angle on its plane.
                var u = _scene.GizmoAxis(_dragAxis);
                float denom = Vector3.Dot(rd, u);
                if (MathF.Abs(denom) > 1e-6f)
                {
                    float t = Vector3.Dot(_scene.Selected.Position - ro, u) / denom;
                    if (t > 0)
                    {
                        var r1 = ro + rd * t - _scene.Selected.Position;
                        if (_dragR0.LengthSquared > 1e-10f && r1.LengthSquared > 1e-10f)
                        {
                            float ang = MathF.Atan2(
                                Vector3.Dot(Vector3.Cross(_dragR0, r1), u),
                                Vector3.Dot(_dragR0, r1)); // radians, geometrically exact
                            if (SnapCheck.IsChecked == true)
                                ang = MathF.Round(ang * 180f / MathF.PI / 15f) * 15f * MathF.PI / 180f;
                            var delta = Quaternion.FromAxisAngle(u, ang);
                            var q = delta * _scene.Selected.Orientation;
                            var nq = System.Numerics.Quaternion.Normalize(
                                new System.Numerics.Quaternion(q.X, q.Y, q.Z, q.W));
                            _scene.Selected.Orientation = new Quaternion(nq.X, nq.Y, nq.Z, nq.W);
                            _scene.Selected.Rotation = SceneObject.QuatToEuler(_scene.Selected.Orientation);
                            _dragR0 = r1;
                            if (_physics.Simulating) _physics.Teleport(_scene.Selected);
                        }
                    }
                }
            }
            else if (_scene.ActiveGizmo == GizmoKind.Scale)
            {
                // Record the raw target; the pump eases _smoothS toward it so sizing
                // glides instead of snapping to the mouse. See ApplyScaleSize.
                float rawS = Vector3.Dot(
                    _scene.AxisPoint(_dragAxis, ro, rd) - _scene.Selected.Position,
                    _scene.GizmoAxis(_dragAxis));
                // Snap the target before easing. Snapping only the eased output
                // made the value oscillate around half-stud boundaries and could
                // leave the final size between increments.
                _scaleRawS = SnapScaleCoordinate(rawS);
            }
            else
            {
                Vector3 np = _scene.AxisPoint(_dragAxis, ro, rd) + _dragOffset;
                if (SnapCheck.IsChecked == true) // stud snapping along the dragged axis
                {
                    var axisVec = _scene.GizmoAxis(_dragAxis);
                    float snapped = MathF.Round(Vector3.Dot(np, axisVec));
                    np += axisVec * (snapped - Vector3.Dot(np, axisVec));
                }
                _scene.Selected.Position = np;
                if (_physics.Simulating) _physics.Teleport(_scene.Selected); // move-drags teleport the body
            }
            UpdateLivePropsThrottled(); // cheap cells only; full rate tanks drag fps
            _scene.InvalidateShadows(); // drags move casters
            _needsFrame = true;
            return;
        }
        if (_lookHeld)
        {
            // Delta from viewport center (Win32 pixels); the warp back to center
            // re-fires this event with ~zero delta, which is harmless.
            var c = ViewportCenterScreen();
            if (GetCursorPos(out var pos))
            {
                _scene.Look(pos.X - (float)c.X, pos.Y - (float)c.Y);
                SetCursorPos((int)c.X, (int)c.Y);
            }
            _needsFrame = true;
            return;
        }
        if (_panHeld)
        {
            var p = e.GetPosition(ViewportControl);
            float dx = (float)(p.X - _lastMouse.X);
            float dy = (float)(p.Y - _lastMouse.Y);
            _lastMouse = p;
            _scene.Pan(dx, dy);
            _needsFrame = true;
            return;
        }
        // Hover: brighten the handle under the cursor (no buttons pressed, gizmo tool active).
        if (_scene.Selected != null && _scene.ActiveGizmo != GizmoKind.None && ViewportControl.ActualWidth > 0)
        {
            var mp = e.GetPosition(ViewportControl);
            float hw = (float)ViewportControl.ActualWidth;
            float hh = (float)ViewportControl.ActualHeight;
            int hov = _scene.ActiveGizmo == GizmoKind.Rotate
                ? _scene.PickRingAxis((float)mp.X, (float)mp.Y, hw, hh, FrameH(), out _)
                : _scene.PickGizmoAxis((float)mp.X, (float)mp.Y, hw, hh, FrameH());
            if (hov != _scene.HoverAxis)
            {
                _scene.HoverAxis = hov;
                _needsFrame = true;
            }
        }
        else if (_scene.HoverAxis != -1)
        {
            _scene.HoverAxis = -1;
            _needsFrame = true;
        }
    }

    /// <summary>Live Properties refresh, at most ~30 Hz during drags.</summary>
    private void UpdateLivePropsThrottled()
    {
        var now = DateTime.UtcNow;
        if ((now - _lastPropPush).TotalMilliseconds < 33) return;
        _lastPropPush = now;
        UpdateLiveProps();
    }

    private void Viewport_MouseUp(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton == MouseButton.Right) _lookHeld = false;
        if (e.ChangedButton == MouseButton.Middle) _panHeld = false;
        if (e.ChangedButton == MouseButton.Left || e.ChangedButton == MouseButton.Right) _orbitHeld = false;
        if (e.ChangedButton == MouseButton.Left)
        {
            bool wasDrag = _dragAxis >= 0;
            bool wasObjectDrag = _objectDrag;
            bool wasScale = wasDrag && _scene.ActiveGizmo == GizmoKind.Scale;
            // Scale drags reshape the body: rebuild it from the final size.
            if (wasScale && _physics.Simulating && _scene.Selected != null)
            {
                ApplyScaleSize(_scaleRawS); // settle exactly on the cursor first
                UpdateLiveProps();
                _physics.RecreateBody(_scene.Selected);
            }
            else if (wasScale && _scene.Selected != null)
            {
                ApplyScaleSize(_scaleRawS); // settle exactly on the cursor
                UpdateLiveProps();
            }
            _dragAxis = -1;
            _objectDrag = false;
            _scene.ActiveAxis = -1;
            if ((wasDrag || wasObjectDrag) && _dragMoved && _dragBefore != null)
                PushCaptured(_dragBefore, mergeable: false); // one step per drag gesture
            _dragBefore = null;
            _dragMoved = false;
        }
        if (!_lookHeld && !_panHeld && !_orbitHeld && _dragAxis < 0 && !_objectDrag)
        {
            ViewportControl.Cursor = null; // restore default arrow
            if (ViewportControl.IsMouseCaptured) ViewportControl.ReleaseMouseCapture();
        }
    }

    /// <summary>End any camera drag and always restore the cursor.</summary>
    private void CancelCameraDrag()
    {
        _lookHeld = false;
        _panHeld = false;
        _orbitHeld = false;
        _dragAxis = -1;
        _objectDrag = false;
        _dragBefore = null;
        _dragMoved = false;
        _scene.ActiveAxis = -1;
        ViewportControl.Cursor = null;
    }

    private Point ViewportCenterScreen()
    {
        return ViewportControl.PointToScreen(
            new Point(ViewportControl.ActualWidth / 2, ViewportControl.ActualHeight / 2));
    }

    private static bool TryRayPlane(Vector3 origin, Vector3 direction, Vector3 planePoint,
        Vector3 planeNormal, out Vector3 hit)
    {
        float denominator = Vector3.Dot(direction, planeNormal);
        if (MathF.Abs(denominator) < 1e-5f)
        {
            hit = Vector3.Zero;
            return false;
        }
        float t = Vector3.Dot(planePoint - origin, planeNormal) / denominator;
        if (t < 0f)
        {
            hit = Vector3.Zero;
            return false;
        }
        hit = origin + direction * t;
        return true;
    }

    private bool TryPlacementSurface(Viewport.SceneObject moving, Vector3 origin, Vector3 direction,
        out Vector3 point, out Vector3 normal)
    {
        point = Vector3.Zero;
        normal = Vector3.Zero;
        float best = float.MaxValue;

        // Infinite build floor at Y=0.
        if (direction.Y < -1e-5f)
        {
            float t = -origin.Y / direction.Y;
            if (t >= 0f && t < best)
            {
                best = t;
                point = origin + direction * t;
                normal = Vector3.UnitY;
            }
        }

        foreach (var other in _scene.Objects)
        {
            if (ReferenceEquals(other, moving)) continue;
            Vector3 half = other.Size * 0.5f;
            Vector3 min = other.Position - half;
            Vector3 max = other.Position + half;
            float tMin = 0f, tMax = float.MaxValue;
            int enterAxis = -1;
            float enterSign = 0f;
            if (!RaySlab(origin.X, direction.X, min.X, max.X, ref tMin, ref tMax, 0, ref enterAxis, ref enterSign) ||
                !RaySlab(origin.Y, direction.Y, min.Y, max.Y, ref tMin, ref tMax, 1, ref enterAxis, ref enterSign) ||
                !RaySlab(origin.Z, direction.Z, min.Z, max.Z, ref tMin, ref tMax, 2, ref enterAxis, ref enterSign))
                continue;
            if (tMin >= 0f && tMin < best)
            {
                best = tMin;
                point = origin + direction * tMin;
                normal = enterAxis == 0 ? new Vector3(enterSign, 0, 0) :
                         enterAxis == 1 ? new Vector3(0, enterSign, 0) :
                         new Vector3(0, 0, enterSign);
            }
        }
        return best < float.MaxValue;
    }

    private static bool RaySlab(float origin, float direction, float min, float max,
        ref float tMin, ref float tMax, int axis, ref int enterAxis, ref float enterSign)
    {
        if (MathF.Abs(direction) < 1e-6f)
            return origin >= min && origin <= max;
        float a = (min - origin) / direction;
        float b = (max - origin) / direction;
        float enter = MathF.Min(a, b), exit = MathF.Max(a, b);
        if (enter > tMin) { tMin = enter; enterAxis = axis; enterSign = a < b ? -1f : 1f; }
        tMax = MathF.Min(tMax, exit);
        return tMin <= tMax;
    }

    /// <summary>Keep a dragged part from passing through the other parts.</summary>
    private Vector3 ConstrainDragPosition(Viewport.SceneObject moving, Vector3 desired)
    {
        Vector3 current = moving.Position;
        Vector3 half = moving.Size * 0.5f;
        foreach (var other in _scene.Objects)
        {
            if (ReferenceEquals(other, moving)) continue;
            Vector3 otherHalf = other.Size * 0.5f;
            Vector3 delta = desired - other.Position;
            if (MathF.Abs(delta.X) >= half.X + otherHalf.X ||
                MathF.Abs(delta.Y) >= half.Y + otherHalf.Y ||
                MathF.Abs(delta.Z) >= half.Z + otherHalf.Z)
                continue;

            // Slide along the nearest separating face instead of entering the part.
            Vector3 min = other.Position - otherHalf - half;
            Vector3 max = other.Position + otherHalf + half;
            Vector3[] candidates =
            {
                new(min.X, desired.Y, desired.Z), new(max.X, desired.Y, desired.Z),
                new(desired.X, min.Y, desired.Z), new(desired.X, max.Y, desired.Z),
                new(desired.X, desired.Y, min.Z), new(desired.X, desired.Y, max.Z),
            };
            float best = float.MaxValue;
            Vector3 chosen = current;
            foreach (var candidate in candidates)
            {
                if (MathF.Abs(candidate.X - other.Position.X) < half.X + otherHalf.X &&
                    MathF.Abs(candidate.Y - other.Position.Y) < half.Y + otherHalf.Y &&
                    MathF.Abs(candidate.Z - other.Position.Z) < half.Z + otherHalf.Z)
                    continue;
                float distance = (candidate - desired).LengthSquared;
                if (distance < best) { best = distance; chosen = candidate; }
            }
            desired = chosen;
        }
        return desired;
    }

    private void Viewport_Wheel(object sender, MouseWheelEventArgs e)
    {
        if (_physics.Simulating && _scene.FollowTarget != null)
        {
            // Play mode: wheel zooms the follow camera, deep range (2..120).
            float zs = AppSettings.Current.ZoomSpeed;
            float dist = Math.Clamp(_scene.FollowDistance, 2f, 120f);
            _scene.FollowDistance = Math.Clamp(
                dist - Math.Sign(e.Delta) * Math.Clamp(dist * 0.15f, 0.3f, 9f) * zs, 2f, 120f);
        }
        else
        {
            float dist = Math.Clamp(_scene.Position.Length, 1.5f, 200f);
            _scene.Dolly((e.Delta > 0 ? 1 : -1) * Math.Clamp(dist * 0.12f, 0.3f, 4f) * AppSettings.Current.ZoomSpeed);
        }
        _needsFrame = true;
    }

    private void Viewport_KeyDown(object sender, KeyEventArgs e)
    {
        bool ctrl = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
        if (e.Key == Key.Delete)
        {
            Delete_Click(sender, e);
            e.Handled = true;
        }
        else if (ctrl && e.Key == Key.D)
        {
            Duplicate_Click(sender, e);
            e.Handled = true;
        }
        else if (e.Key == Key.F5)
        {
            if (e.KeyboardDevice.Modifiers.HasFlag(ModifierKeys.Shift)) StopPlaying();
            else StartPlaying();
            e.Handled = true;
        }
        else if (e.Key == Key.F)
        {
            if (_scene.Selected is { } sel)
            {
                _scene.FocusOn(sel.Position, sel.Size.Length / 2f);
                Log($"Focused {sel.Name} (F).");
            }
            else
            {
                _scene.ResetCamera();
                Log("Camera reset to origin (F, nothing selected).");
            }
            _needsFrame = true;
        }
        else if (e.Key is Key.W or Key.A or Key.S or Key.D or Key.Q or Key.E or Key.LeftShift or Key.RightShift)
        {
            _needsFrame = true; // kick the loop so key polling resumes from idle
        }
    }

    // ---------- ribbon ----------

    private void RibbonButton_Click(object sender, RoutedEventArgs e)
    {
        string header = sender switch
        {
            Fluent.Button b => b.Header?.ToString() ?? "Button",
            Fluent.ToggleButton t => t.Header?.ToString() ?? "Toggle",
            Button b => b.Content?.ToString() ?? "Button",
            _ => sender?.GetType().Name ?? "?"
        };
        Log($"Ribbon: {header}");
        StatusText.Text = header;
    }

    private void Tool_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Fluent.ToggleButton t)
        {
            _tool = t.Header?.ToString()?.Split(' ').Last() ?? "Select";
            ToolLabel.Text = $"Tool: {_tool}";
            _scene.ActiveGizmo = _tool switch
            {
                "Move" => GizmoKind.Move,
                "Scale" => GizmoKind.Scale,
                "Rotate" => GizmoKind.Rotate,
                _ => GizmoKind.None, // Select just selects
            };
            Log($"Tool → {_tool}");
            StatusText.Text = $"Tool: {_tool}";
        }
    }

    private void Anchor_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected is not { } sel) return;
        PushUndo("Anchored", mergeable: false);
        sel.Anchored = (sender as Fluent.ToggleButton)?.IsChecked == true;
        if (_physics.Simulating) _physics.RecreateBody(sel); // static <-> dynamic swap
        MarkDirty();
        SyncAnchorToggle(); // keep the Home + Model toggles identical
        UpdateLiveProps();
        Log($"⚓ {sel.Name} {(sel.Anchored ? "anchored" : "unanchored")}.");
        StatusText.Text = $"{sel.Name} {(sel.Anchored ? "anchored" : "unanchored")}";
    }

    /// <summary>Mirror the selection's anchored state onto both ribbon toggles.</summary>
    private void SyncAnchorToggle()
    {
        if (_scene.Selected is { } sel)
        {
            AnchorToggle.IsEnabled = true;
            AnchorToggle.IsChecked = sel.Anchored;
            AnchorToggleHome.IsEnabled = true;
            AnchorToggleHome.IsChecked = sel.Anchored;
        }
        else
        {
            AnchorToggle.IsChecked = false;
            AnchorToggle.IsEnabled = false;
            AnchorToggleHome.IsChecked = false;
            AnchorToggleHome.IsEnabled = false;
        }
    }

    private void Duplicate_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected is not { } sel)
        {
            Log("Duplicate: nothing selected.");
            StatusText.Text = "Nothing to duplicate";
            return;
        }
        var copy = sel.Clone(sel.Name);
        PushUndo("Duplicate", mergeable: false);
        _scene.Objects.Add(copy);
        _physics.AddBody(copy); // no-op unless playing
        _scene.InvalidateShadows(); // new caster
        SelectObject(copy);
        Log($"Duplicated {sel.Name} → {copy.Name}.");
        StatusText.Text = $"Duplicated {copy.Name}";
        MarkDirty();
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected is not { } sel)
        {
            Log("Delete: nothing selected.");
            StatusText.Text = "Nothing to delete";
            return;
        }
        int idx = _scene.Objects.IndexOf(sel);
        PushUndo("Delete", mergeable: false);
        _physics.RemoveBody(sel); // no-op unless playing
        if (ReferenceEquals(sel, _physics.Player))
        {
            // The avatar's object is gone: drop its face panel too, stop driving/following.
            var face = _physics.FaceObject;
            if (face != null) _scene.Objects.Remove(face);
            _physics.ClearPlayer();
            _scene.FollowTarget = null;
        }
        _scene.Objects.Remove(sel);
        _scene.InvalidateShadows(); // caster gone
        MarkDirty();
        SelectObject(_scene.Objects.Count > 0
            ? _scene.Objects[Math.Min(idx, _scene.Objects.Count - 1)]
            : null);
        Log($"Deleted {sel.Name}.");
        StatusText.Text = $"Deleted {sel.Name}";
    }

    private void InsertPart_Click(object sender, RoutedEventArgs e) =>
        InsertShape(ShapeKind.Block, "Part");

    private void InsertWedge_Click(object sender, RoutedEventArgs e) =>
        InsertShape(ShapeKind.Wedge, "Wedge");

    /// <summary>Home-tab Insert dropdown: the shape comes from the menu item's Tag.</summary>
    private void InsertShape_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement fe && fe.Tag is string tag &&
            Enum.TryParse<ShapeKind>(tag, out var shape))
            InsertShape(shape, shape.ToString());
    }

    /// <summary>Insert a Spawn point: anchored gray pad, flagged for Play start.</summary>
    private void InsertSpawn_Click(object sender, RoutedEventArgs e)
    {
        PushUndo("Insert", mergeable: false);
        _partCounter++;
        Vector3 at = _scene.Position + _scene.Forward * 6f;
        if (SnapCheck.IsChecked == true)
            at = new Vector3(MathF.Round(at.X), MathF.Round(at.Y), MathF.Round(at.Z));
        var obj = new SceneObject
        {
            Name = $"Spawn {_partCounter}",
            Shape = ShapeKind.Block,
            Position = at,
            Size = new Vector3(2.0f, 0.5f, 2.0f),
            Color = new Color4(0.75f, 0.75f, 0.78f, 1f),
            Anchored = true,
            IsSpawn = true,
        };
        _scene.Objects.Add(obj);
        _physics.AddBody(obj); // no-op unless playing
        _scene.InvalidateShadows(); // new caster
        SelectObject(obj);
        Log($"Inserted {obj.Name} (spawn point) in front of camera.");
        StatusText.Text = $"Inserted {obj.Name}";
        MarkDirty();
    }

    private void InsertShape(ShapeKind shape, string prefix)
    {
        PushUndo("Insert", mergeable: false);
        _partCounter++;
        Vector3 at = _scene.Position + _scene.Forward * 6f;
        if (SnapCheck.IsChecked == true)
            at = new Vector3(MathF.Round(at.X), MathF.Round(at.Y), MathF.Round(at.Z));
        var obj = new SceneObject
        {
            Name = $"{prefix} {_partCounter}",
            Shape = shape,
            Position = at,
            Size = new Vector3(2, 2, 2),
            Color = Palette[_scene.Objects.Count % Palette.Length],
        };
        _scene.Objects.Add(obj);
        _physics.AddBody(obj); // no-op unless playing
        _scene.InvalidateShadows(); // new caster
        SelectObject(obj);
        Log($"Inserted {obj.Name} in front of camera.");
        StatusText.Text = $"Inserted {obj.Name}";
        MarkDirty();
    }

    private void Play_Click(object sender, RoutedEventArgs e)
    {
        string h = (sender as Fluent.Button)?.Header?.ToString() ?? "";
        if (h.Contains("Stop")) StopPlaying();
        else StartPlaying();
    }

    private void StartPlaying()
    {
        if (_physics.Simulating)
        {
            Log("Already playing.");
            return;
        }
        _scene.PhysicsDriven = true; // bodies own the transforms
        try
        {
            if (_physics.StartPlay(_scene, Log, AppSettings.Current.GravityStrength))
            {
                StatusText.Text = "▶ Playing...";
                CancelCameraDrag();
                // Spawn the avatar on the first Spawn part, else over the baseplate.
                var spawn = _scene.Objects.FirstOrDefault(o => o.IsSpawn);
                Vector3 at = spawn != null
                    ? spawn.Position + new Vector3(0, spawn.Size.Y * 0.5f + 0.75f + 0.3f, 0)
                    : new Vector3(0, AppSettings.Current.PlayerSpawnHeight, 0);
                var player = new SceneObject
                {
                    Name = "Player",
                    Shape = ShapeKind.Capsule,
                    Position = at,
                    Size = new Vector3(1.5f, 1.5f, 1.5f),
                    Color = new Color4(0.2f, 0.5f, 1f, 1f),
                    Material = MaterialKind.Plastic,
                    Anchored = false,
                };
                _scene.Objects.Add(player);
                _physics.SpawnPoint = at; // void falls respawn here too
                string faceDir = Path.Combine(AppContext.BaseDirectory, "Faces");
                _faceOpenPath = Path.Combine(faceDir, "face.png");
                _faceBlinkPath = Path.Combine(faceDir, "blink.png");
                if (!File.Exists(_faceOpenPath) || !File.Exists(_faceBlinkPath))
                {
                    Log("Avatar face skipped: Faces/face.png or blink.png missing next to the exe.");
                    _faceOpenPath = _faceBlinkPath = null;
                }
                else
                {
                    // Separate non-colliding face panel riding the avatar: free 3D
                    // placement, no UV distortion. Managed (hidden, unsaved).
                    var face = new SceneObject
                    {
                        Name = "Face",
                        Shape = ShapeKind.Block,
                        Position = at + _physics.FaceOffset,
                        Size = new Vector3(0.7f, 0.7f, 0.05f),
                        Color = new Color4(0.2f, 0.5f, 1f, 1f),
                        Anchored = true,
                        CanCollide = false,
                        IsAvatarFace = true,
                        Transparency = 1f, // panel invisible; only its face decal shows
                    };
                    face.Decals.Add(new Viewport.DecalLayer { Image = _faceOpenPath, Face = "Front" });
                    _scene.Objects.Add(face);
                    _physics.FaceObject = face;
                }
                _playStartUtc = DateTime.UtcNow;
                _physics.SpawnPlayer(player);
                _scene.FollowTarget = player;
                _scene.FollowDistance = AppSettings.Current.PlayerZoom;
                _physics.PlayerCamYaw = _scene.Yaw;
                SelectObject(null); // play mode starts with nothing selected
                _scene.InvalidateShadows();
                _needsFrame = true;
                Log($"Play: Bepu simulation running (gravity {AppSettings.Current.GravityStrength}).");
                Log(spawn != null
                    ? $"Spawned Player on {spawn.Name}: WASD move · Space jump · drag to orbit · wheel to zoom."
                    : "Spawned Player (blue capsule 1.5): WASD move · Space jump · drag to orbit · wheel to zoom.");
            }
            else _scene.PhysicsDriven = false;
        }
        catch (Exception ex)
        {
            _physics.StopPlay(_scene);
            _scene.PhysicsDriven = false;
            StatusText.Text = "Physics failed";
            Log("Play failed: " + ex.Message);
        }
    }

    private void StopPlaying()
    {
        if (_physics.Simulating)
        {
            var avatar = _physics.Player;
            var face = _physics.FaceObject;
            _physics.StopPlay(_scene); // clears Player + FaceObject, restores part poses
            if (avatar != null) _scene.Objects.Remove(avatar);
            if (face != null) _scene.Objects.Remove(face);
            _scene.FollowTarget = null;
            _scene.PhysicsDriven = false;
            CancelCameraDrag();
            if (ReferenceEquals(_scene.Selected, avatar)) SelectObject(null);
            else RefreshExplorer(); // drop the Player node from the tree
            _scene.InvalidateShadows(); // restored poses need a fresh depth map
            _needsFrame = true;         // ...and a present to draw it, even if idle
            StatusText.Text = "⏹ Stopped";
            Log("Stopped: poses restored.");
        }
        else
        {
            StatusText.Text = "⏹ Stopped";
            Log("Stop: nothing playing.");
        }
    }

    // ---------- undo / redo (edit-mode scene snapshots) ----------
    //
    // Whole-scene copies: one uniform mechanism for inserts, deletes, property
    // edits, decals, lighting and drags. Edit mode only — undo while playing
    // would orphan physics bodies, so it asks you to stop first.

    private sealed class SceneSnapshot
    {
        public string Label = "";
        public string MergeKey = "";
        public List<SceneObject> Parts = new();
        public int SelectedIndex = -1;
        public int PartCounter;
        public Vector3 SunDirection;
        public Vector3 SunColor;
        public float SunIntensity;
        public bool Shadows;
        public float Ambient;
        public float FogDensity;
        public Vector3 FogColor;
        public float Haze;
        public float Time;
    }

    private readonly List<SceneSnapshot> _undo = new();
    private readonly List<SceneSnapshot> _redo = new();
    private string? _lastUndoKey;
    private DateTime _lastUndoTime;
    private bool _restoringHistory;
    private SceneSnapshot? _dragBefore;
    private bool _dragMoved;

    private SceneSnapshot CaptureState(string tag) => new()
    {
        Label = tag,
        MergeKey = tag,
        Parts = _scene.Objects.Select(o => o.Clone(o.Name)).ToList(),
        SelectedIndex = _scene.Selected != null ? _scene.Objects.IndexOf(_scene.Selected) : -1,
        PartCounter = _partCounter,
        SunDirection = _scene.SunDirection,
        SunColor = _scene.SunColor,
        SunIntensity = _scene.SunIntensity,
        Shadows = _scene.ShadowsEnabled,
        Ambient = _scene.AmbientBoost,
        FogDensity = _scene.FogDensity,
        FogColor = _scene.FogColor,
        Haze = _scene.SkyHaze,
        Time = _scene.TimeOfDay,
    };

    private void PushCaptured(SceneSnapshot snap, bool mergeable)
    {
        if (_restoringHistory || _physics.Simulating) return;
        if (mergeable)
        {
            // Coalesce floods (slider drags) into one step per target.
            var now = DateTime.UtcNow;
            if (snap.MergeKey == _lastUndoKey && (now - _lastUndoTime).TotalSeconds < 2) return;
            _lastUndoKey = snap.MergeKey;
            _lastUndoTime = now;
        }
        if (_undo.Count >= 100) _undo.RemoveAt(0);
        _undo.Add(snap);
        _redo.Clear();
        UpdateUndoButtons();
    }

    private void PushUndo(string tag, bool mergeable = true) => PushCaptured(CaptureState(tag), mergeable);

    private void RestoreState(SceneSnapshot snap)
    {
        _restoringHistory = true;
        try
        {
            _scene.Objects.Clear();
            foreach (var p in snap.Parts) _scene.Objects.Add(p.Clone(p.Name)); // re-clone: history must stay frozen
            _partCounter = snap.PartCounter;
            _scene.SunDirection = snap.SunDirection;
            _scene.SunColor = snap.SunColor;
            _scene.SunIntensity = snap.SunIntensity;
            ApplyShadows(snap.Shadows);
            _scene.AmbientBoost = snap.Ambient;
            ApplyFog(snap.FogDensity);
            _scene.FogColor = snap.FogColor;
            _scene.SkyHaze = snap.Haze;
            TimeSlider.Value = snap.Time;
            _lastUndoKey = null;
            RefreshExplorer();
            SelectObject(snap.SelectedIndex >= 0 && snap.SelectedIndex < _scene.Objects.Count
                ? _scene.Objects[snap.SelectedIndex] : null);
            _scene.InvalidateShadows();
            _needsFrame = true;
            MarkDirty();
        }
        finally { _restoringHistory = false; }
        UpdateUndoButtons();
    }

    private void UpdateUndoButtons()
    {
        UndoButton.IsEnabled = _undo.Count > 0;
        RedoButton.IsEnabled = _redo.Count > 0;
    }

    private void Undo_Click(object sender, RoutedEventArgs e) => Undo();

    private void Redo_Click(object sender, RoutedEventArgs e) => Redo();

    private void Undo()
    {
        if (_physics.Simulating)
        {
            StatusText.Text = "Stop playing to undo";
            Log("Undo: stop playing first.");
            return;
        }
        if (_undo.Count == 0)
        {
            StatusText.Text = "Nothing to undo";
            return;
        }
        var snap = _undo[^1];
        _undo.RemoveAt(_undo.Count - 1);
        _redo.Add(CaptureState(snap.Label)); // redo re-applies the same action
        RestoreState(snap);
        Log($"Undo {snap.Label}.");
        StatusText.Text = $"Undo {snap.Label}";
        UpdateUndoButtons();
    }

    private void Redo()
    {
        if (_physics.Simulating)
        {
            StatusText.Text = "Stop playing to redo";
            Log("Redo: stop playing first.");
            return;
        }
        if (_redo.Count == 0)
        {
            StatusText.Text = "Nothing to redo";
            return;
        }
        var snap = _redo[^1];
        _redo.RemoveAt(_redo.Count - 1);
        var cur = CaptureState(snap.Label);
        if (_undo.Count >= 100) _undo.RemoveAt(0);
        _undo.Add(cur);
        RestoreState(snap);
        Log($"Redo {snap.Label}.");
        StatusText.Text = $"Redo {snap.Label}";
        UpdateUndoButtons();
    }

    // ---------- place files (.bp) ----------

    private string? _savePath;
    private bool _dirty;

    private static readonly JsonSerializerOptions PlaceJson = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() },
    };

    private void MarkDirty()
    {
        if (_dirty) return;
        _dirty = true;
        UpdateTitle();
    }

    private void UpdateTitle()
    {
        string name = _savePath != null ? Path.GetFileName(_savePath) : "Untitled";
        Title = $"builder engine : {name}" + (_dirty ? " •" : "");
    }

    private static float[] V3(Vector3 v) => new[] { v.X, v.Y, v.Z };

    private static Vector3 F3(float[]? a, Vector3 fallback) =>
        a is { Length: 3 } ? new Vector3(a[0], a[1], a[2]) : fallback;

    private static Vector3 ClampSize(Vector3 s) =>
        new(Math.Max(s.X, 0.05f), Math.Max(s.Y, 0.05f), Math.Max(s.Z, 0.05f));

    private static float Clamp01(float v) => Math.Clamp(v, 0f, 1f);

    private PlaceFile CapturePlace()
    {
        var file = new PlaceFile
        {
            Sun = new SunDto
            {
                Direction = V3(_scene.SunDirection),
                Color = V3(_scene.SunColor),
                Intensity = _scene.SunIntensity,
                Shadows = _scene.ShadowsEnabled,
            },
            Atmosphere = new AtmosphereDto
            {
                FogDensity = _scene.FogDensity,
                FogColor = V3(_scene.FogColor),
                Haze = _scene.SkyHaze,
            },
            Ambient = _scene.AmbientBoost,
            TimeOfDay = _scene.TimeOfDay,
            Camera = new CameraDto
            {
                Position = V3(_scene.Position),
                Yaw = _scene.Yaw,
                Pitch = _scene.Pitch,
            },
        };
        foreach (var o in _scene.Objects)
        {
            if (ReferenceEquals(o, _physics.Player)) continue; // never persist the avatar
            if (o.IsAvatarFace) continue; // managed face panel: never persist
            var p = new PartDto
            {
                Name = o.Name,
                Shape = o.Shape,
                Position = V3(o.Position),
                Size = V3(o.Size),
                Rotation = V3(o.Rotation),
                Color = new[] { o.Color.R, o.Color.G, o.Color.B },
                Material = o.Material,
                Anchored = o.Anchored,
                IsSpawn = o.IsSpawn,
                Mass = o.Mass,
                CanCollide = o.CanCollide,
                Transparency = o.Transparency,
                Reflectance = o.Reflectance,
                CastShadow = o.CastShadow,
                DecalImage = o.DecalImage,
                DecalFace = o.DecalFace,
                DecalTransparency = o.DecalTransparency,
                DecalBlur = o.DecalBlur,
            };
            foreach (var d in o.Decals)
            {
                if (string.IsNullOrWhiteSpace(d.Image)) continue;
                p.Decals.Add(new DecalDto
                {
                    Image = d.Image,
                    Face = d.Face,
                    Transparency = d.Transparency,
                    Blur = d.Blur,
                    OffsetX = d.OffsetX,
                    OffsetY = d.OffsetY,
                    Scale = d.Scale,
                });
            }
            foreach (var t in o.Texts)
            {
                p.Texts.Add(new TextDto
                {
                    Text = t.Text,
                    Face = t.Face,
                    Font = t.Font,
                    Size = t.Size,
                    Color = t.Color,
                    Transparency = t.Transparency,
                    Blur = t.Blur,
                    OffsetX = t.OffsetX,
                    OffsetY = t.OffsetY,
                    Scale = t.Scale,
                });
            }
            file.Parts.Add(p);
        }
        return file;
    }

    private bool WritePlace(string path)
    {
        try
        {
            File.WriteAllText(path, JsonSerializer.Serialize(CapturePlace(), PlaceJson));
            _savePath = path;
            _dirty = false;
            UpdateTitle();
            Log($"Saved {path} ({_scene.Objects.Count} parts).");
            StatusText.Text = $"Saved {Path.GetFileName(path)}";
            return true;
        }
        catch (Exception ex)
        {
            Log("Save failed: " + ex.Message);
            StatusText.Text = "Save failed";
            return false;
        }
    }

    /// <summary>Save to the current path, prompting when there isn't one yet.</summary>
    public bool SavePlace() => _savePath != null ? WritePlace(_savePath) : SavePlaceAs();

    private bool SavePlaceAs()
    {
        var dialog = new SaveFileDialog
        {
            Title = "Save place",
            Filter = "Builder Place (*.bp)|*.bp|All files|*.*",
            DefaultExt = ".bp",
            AddExtension = true,
            FileName = _savePath != null ? Path.GetFileName(_savePath) : "Untitled.bp",
            OverwritePrompt = true,
        };
        if (dialog.ShowDialog(this) != true) return false;
        return WritePlace(dialog.FileName);
    }

    private void LoadPlace(PlaceFile file, string path)
    {
        _scene.Objects.Clear();
        foreach (var p in file.Parts ?? new List<PartDto>())
        {
            var o = new SceneObject
            {
                Name = string.IsNullOrWhiteSpace(p.Name) ? "Part" : p.Name,
                Shape = Enum.IsDefined(p.Shape) ? p.Shape : ShapeKind.Block,
                Position = F3(p.Position, Vector3.Zero),
                Size = ClampSize(F3(p.Size, new Vector3(2, 2, 2))),
                Rotation = F3(p.Rotation, Vector3.Zero),
                Color = new Color4(
                    Clamp01(F3(p.Color, new Vector3(0.25f, 0.55f, 0.95f)).X),
                    Clamp01(F3(p.Color, new Vector3(0.25f, 0.55f, 0.95f)).Y),
                    Clamp01(F3(p.Color, new Vector3(0.25f, 0.55f, 0.95f)).Z), 1f),
                Material = Enum.IsDefined(p.Material) ? p.Material : MaterialKind.Plastic,
                Anchored = p.Anchored,
                IsSpawn = p.IsSpawn,
                Mass = Math.Clamp(p.Mass <= 0 ? 1f : p.Mass, 0.01f, 100f),
                CanCollide = p.CanCollide,
                Transparency = Clamp01(p.Transparency),
                Reflectance = Clamp01(p.Reflectance),
                CastShadow = p.CastShadow,
                DecalImage = string.IsNullOrWhiteSpace(p.DecalImage) ? null : p.DecalImage,
                DecalFace = p.DecalFace,
                DecalTransparency = Clamp01(p.DecalTransparency),
                DecalBlur = Clamp01(p.DecalBlur),
            };
            o.ComposeOrientation();
            foreach (var d in p.Decals ?? new List<DecalDto>())
            {
                if (string.IsNullOrWhiteSpace(d.Image)) continue;
                o.Decals.Add(new DecalLayer
                {
                    Image = d.Image,
                    Face = d.Face,
                    Transparency = Clamp01(d.Transparency),
                    Blur = Clamp01(d.Blur),
                    OffsetX = Math.Clamp(d.OffsetX, -1f, 1f),
                    OffsetY = Math.Clamp(d.OffsetY, -1f, 1f),
                    Scale = Math.Clamp(d.Scale <= 0 ? 1f : d.Scale, 0.05f, 1f),
                });
            }
            foreach (var t in p.Texts ?? new List<TextDto>())
            {
                o.Texts.Add(new TextLayer
                {
                    Text = string.IsNullOrEmpty(t.Text) ? "Text" : t.Text.Length > 200 ? t.Text[..200] : t.Text,
                    Face = t.Face,
                    Font = Viewport.TextFonts.OrFallback(t.Font),
                    Size = Math.Clamp(t.Size <= 0 ? 48 : t.Size, 8f, 256f),
                    Color = t.Color,
                    Transparency = Clamp01(t.Transparency),
                    Blur = Clamp01(t.Blur),
                    OffsetX = Math.Clamp(t.OffsetX, -1f, 1f),
                    OffsetY = Math.Clamp(t.OffsetY, -1f, 1f),
                    Scale = Math.Clamp(t.Scale <= 0 ? 1f : t.Scale, 0.05f, 1f),
                });
            }
            _scene.Objects.Add(o);
        }
        _scene.SunDirection = F3(file.Sun?.Direction, new Vector3(0.5f, 0.8f, 0.6f));
        _scene.SunColor = F3(file.Sun?.Color, new Vector3(1f, 0.97f, 0.92f));
        _scene.SunIntensity = Math.Clamp(file.Sun?.Intensity ?? 1f, 0f, 2f);
        ApplyShadows(file.Sun?.Shadows ?? true);
        _scene.AmbientBoost = Math.Clamp(file.Ambient, 0f, 2f);
        ApplyFog(Math.Clamp(file.Atmosphere?.FogDensity ?? 0.012f, 0f, 0.05f));
        _scene.FogColor = F3(file.Atmosphere?.FogColor, new Vector3(0.55f, 0.62f, 0.72f));
        _scene.SkyHaze = Math.Clamp(file.Atmosphere?.Haze ?? 0.012f, 0f, 0.05f);
        TimeSlider.Value = Math.Clamp(file.TimeOfDay, 0f, 24f);
        _scene.Position = F3(file.Camera?.Position, new Vector3(0, 1.5f, 8f));
        _scene.Yaw = file.Camera?.Yaw ?? -90f;
        _scene.Pitch = file.Camera?.Pitch ?? -10f;
        _partCounter = _scene.Objects.Count;
        _savePath = path;
        _dirty = false;
        _undo.Clear();
        _redo.Clear();
        _lastUndoKey = null;
        UpdateTitle();
        RefreshExplorer();
        SelectObject(null);
        _scene.InvalidateShadows();
        _needsFrame = true;
        Log($"Opened {path} ({_scene.Objects.Count} parts).");
        StatusText.Text = $"Opened {Path.GetFileName(path)}";
    }

    private void OpenPlace()
    {
        if (_physics.Simulating) StopPlaying();
        if (!ConfirmDiscard("open a place")) return;
        var dialog = new OpenFileDialog
        {
            Title = "Open place",
            Filter = "Builder Place (*.bp)|*.bp|All files|*.*",
            CheckFileExists = true,
        };
        if (dialog.ShowDialog(this) != true) return;
        PlaceFile file;
        try
        {
            file = JsonSerializer.Deserialize<PlaceFile>(File.ReadAllText(dialog.FileName), PlaceJson)
                ?? throw new InvalidDataException("Empty place file.");
        }
        catch (Exception ex)
        {
            Log("Open failed: " + ex.Message);
            StatusText.Text = "Open failed";
            return;
        }
        if (file.Format != 1)
        {
            Log($"Open failed: unsupported place format {file.Format} (want 1).");
            StatusText.Text = "Unsupported place format";
            return;
        }
        LoadPlace(file, dialog.FileName);
    }

    private void NewPlace()
    {
        if (_physics.Simulating) StopPlaying();
        if (!ConfirmDiscard("create a new place")) return;
        _scene.Objects.Clear();
        _scene.Objects.Add(new SceneObject
        {
            Name = "Baseplate",
            Shape = ShapeKind.Block,
            Position = new Vector3(0, -0.5f, 0),
            Size = new Vector3(32, 1, 32),
            Color = new Color4(0.64f, 0.635f, 0.647f, 1f),
            Anchored = true,
        });
        _partCounter = 0;
        _scene.ResetCamera();
        _savePath = null;
        _dirty = false;
        _undo.Clear();
        _redo.Clear();
        _lastUndoKey = null;
        UpdateTitle();
        RefreshExplorer();
        SelectObject(null);
        _scene.InvalidateShadows();
        _needsFrame = true;
        Log("New place (baseplate).");
        StatusText.Text = "New place";
    }

    /// <summary>True = proceed. Anything but Yes aborts (safe under any dialog dismissal).</summary>
    private bool ConfirmDiscard(string action)
    {
        if (!_dirty) return true;
        var confirm = new ConfirmWindow { Owner = this };
        confirm.Message = $"Discard unsaved changes and {action}? (Ctrl+S keeps them)";
        bool proceed = confirm.ShowDialog() == true;
        if (!proceed) Log("Kept current place (Ctrl+S to save).");
        return proceed;
    }

    private void CloseBackstage()
    {
        if (MainRibbon.Menu is Fluent.Backstage backstage) backstage.IsOpen = false;
    }

    private void New_Click(object sender, RoutedEventArgs e)
    {
        NewPlace();
        CloseBackstage();
    }

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        OpenPlace();
        CloseBackstage();
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (SavePlace()) CloseBackstage();
    }

    private void SaveAs_Click(object sender, RoutedEventArgs e)
    {
        if (SavePlaceAs()) CloseBackstage();
    }

    private void ToggleExplorer_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        if (on) { LeftCol.Width = _leftWidth; ExplorerPanel.Visibility = Visibility.Visible; }
        else { _leftWidth = LeftCol.Width; LeftCol.Width = new GridLength(0); ExplorerPanel.Visibility = Visibility.Collapsed; }
    }

    private void ToggleProperties_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        if (on) { RightCol.Width = _rightWidth; PropertiesPanel.Visibility = Visibility.Visible; }
        else { _rightWidth = RightCol.Width; RightCol.Width = new GridLength(0); PropertiesPanel.Visibility = Visibility.Collapsed; }
    }

    private void ToggleOutput_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        OutputPanel.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
        OutputRow.Height = on ? new GridLength(170) : new GridLength(0);
    }

    private void VSync_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        ApplyVsync(on);
        Log(on
            ? $"VSync on: compositor-paced presentation (≈{_refreshHz:0} Hz)."
            : "VSync off: render on every compositor tick.");
    }

    private void Msaa_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        ApplyMsaa(on);
        _needsFrame = true; // framebuffer reallocates
        Log($"MSAA {(on ? "4x on" : "off")}.");
    }

    private void Shadows_Click(object sender, RoutedEventArgs e)
    {
        bool on = (sender as Fluent.ToggleButton)?.IsChecked == true;
        ApplyShadows(on);
        Log($"Shadows {(on ? "on" : "off")}.");
    }

    private void ThemeToggle_Click(object sender, RoutedEventArgs e)
    {
        bool dark = (sender as Fluent.ToggleButton)?.IsChecked == true;
        SetTheme(dark);
        Log($"Theme → {(dark ? "Dark.Cobalt" : "Light.Cobalt")}.");
    }

    private void TimeSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (TimeSlider == null || TimeLabel == null) return; // still in InitializeComponent
        float t = (float)TimeSlider.Value;
        if (IsLoaded) PushUndo("Time"); // skip the programmatic init set, coalesce drags
        _scene.SetTimeOfDay(t);
        TimeLabel.Text = $"{(int)t:00}:{(int)((t - Math.Floor(t)) * 60):00}";
        AppSettings.Current.TimeOfDay = t;
        AppSettings.Current.Save();
        UpdateLiveProps(); // Sun rows stay truthful if selected
        MarkDirty(); // time of day is place content
        _needsFrame = true;
    }

    // ---------- settings ----------

    /// <summary>Apply the whole persisted config (called once at startup).</summary>
    public void ApplyAllSettings()
    {
        var s = AppSettings.Current;
        ApplyCameraSettings();
        ApplyPlayerSettings();
        _scene.PulseStrength = s.SelectionGlow;
        _physics.Friction = s.Friction;
        SnapCheck.IsChecked = s.SnapEnabled;
        _scene.FovDeg = s.Fov;
        _scene.FogDensity = s.FogDensity;
        _scene.SetTimeOfDay(s.TimeOfDay);
        _vsync = s.VSync;
        VSyncToggle.IsChecked = s.VSync;
        MsaaToggle.IsChecked = s.Msaa;
        ShadowsToggle.IsChecked = s.Shadows;
        _scene.ShadowsEnabled = s.Shadows;
        _scene.RequestShadowSize(s.ShadowSize);
        _scene.ShadowDistance = s.ShadowDistance;
        DarkToggle.IsChecked = s.DarkTheme; // theme itself applied in App.OnStartup
        ApplyWindowMode(s.WindowMode, save: false);
    }

    public void ApplyCameraSettings()
    {
        _scene.LookSensitivity = AppSettings.Current.LookSensitivity;
        _scene.MoveSpeed = AppSettings.Current.MoveSpeed;
        _scene.LookResponsiveness = AppSettings.Current.LookSmoothing;
        _scene.MoveResponsiveness = AppSettings.Current.MoveSmoothing;
        _scene.InvertLookY = AppSettings.Current.InvertLookY;
    }

    /// <summary>Selection glow 0-1 (slider, saved immediately).</summary>
    public void ApplySelectionGlow(float glow)
    {
        glow = Math.Clamp(glow, 0f, 1f);
        _scene.PulseStrength = glow;
        AppSettings.Current.SelectionGlow = glow;
        AppSettings.Current.Save();
        _needsFrame = true;
    }

    /// <summary>Persisted stud-snap default for the view bar toggle.</summary>
    public void ApplySnapDefault(bool on)
    {
        SnapCheck.IsChecked = on;
        AppSettings.Current.SnapEnabled = on;
        AppSettings.Current.Save();
    }

    private void SnapCheck_Click(object sender, RoutedEventArgs e)
    {
        ApplySnapDefault(SnapCheck.IsChecked == true);
        Log($"Snap {(SnapCheck.IsChecked == true ? "on (1 stud)" : "off")}.");
    }

    /// <summary>Contact friction (applies on the next Play, like gravity).</summary>
    public void ApplyFriction(float friction)
    {
        friction = Math.Clamp(friction, 0f, 2f);
        _physics.Friction = friction;
        AppSettings.Current.Friction = friction;
        AppSettings.Current.Save();
    }

    /// <summary>Push persisted player tuning into the sim (drive reads it live).</summary>
    public void ApplyPlayerSettings()
    {
        _physics.WalkSpeed = AppSettings.Current.PlayerWalkSpeed;
        _physics.JumpSpeed = AppSettings.Current.PlayerJumpPower;
        _physics.CoyoteTime = AppSettings.Current.PlayerCoyote;
        if (_scene.FollowTarget != null)
            _scene.FollowDistance = AppSettings.Current.PlayerZoom;
    }

    public void ApplyFov(float fov)
    {
        _scene.FovDeg = fov;
        AppSettings.Current.Fov = fov;
        AppSettings.Current.Save();
    }

    public void ApplyFog(float density)
    {
        _scene.FogDensity = density;
        AppSettings.Current.FogDensity = density;
        AppSettings.Current.Save();
        MarkDirty(); // fog is place content
    }

    public void RequestShadowSize(int size)
    {
        AppSettings.Current.ShadowSize = size is 256 or 512 or 1024 or 2048 or 4096 ? size : 1024;
        AppSettings.Current.Save();
        _scene.RequestShadowSize(AppSettings.Current.ShadowSize);
    }

    /// <summary>Shadow frustum half-extent in studs (live: snap math reads it per frame).</summary>
    public void ApplyShadowDistance(float distance)
    {
        distance = Math.Clamp(distance, 10f, 120f);
        AppSettings.Current.ShadowDistance = distance;
        AppSettings.Current.Save();
        _scene.ShadowDistance = distance;
        _needsFrame = true;
    }

    /// <summary>Keep the Cobalt accent so it matches the #007ACC status bar; just flip base.</summary>
    public void SetTheme(bool dark)
    {
        AppSettings.Current.DarkTheme = dark;
        ThemeManager.Current.ChangeTheme(Application.Current, dark ? "Dark.Cobalt" : "Light.Cobalt");
        if (DarkToggle.IsChecked != dark) DarkToggle.IsChecked = dark;
        AppSettings.Current.Save();
    }

    public void ApplyVsync(bool on)
    {
        _vsync = on;
        AppSettings.Current.VSync = on;
        AppSettings.Current.Save();
    }

    public void ApplyMsaa(bool on)
    {
        AppSettings.Current.Msaa = on;
        // Takes effect live: the control reallocates its framebuffer when Samples changes.
        if (_glStarted) ViewportControl.Settings.Samples = on ? 4 : 0;
        AppSettings.Current.Save();
    }

    public void ApplyShadows(bool on)
    {
        AppSettings.Current.Shadows = on;
        if (ShadowsToggle.IsChecked != on) ShadowsToggle.IsChecked = on;
        _scene.ShadowsEnabled = on;
        _needsFrame = true;
        AppSettings.Current.Save();
    }

    public void ApplyWindowMode(string mode, bool save = true)
    {
        AppSettings.Current.WindowMode = mode;
        if (mode == "Borderless")
        {
            if (!_winBoundsSaved && WindowState == WindowState.Normal &&
                !double.IsNaN(Left) && !double.IsNaN(Top))
            {
                _winBounds = new Rect(Left, Top, Width, Height);
                _winBoundsSaved = true;
            }
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
        }
        else
        {
            // Restore in this order so the OS frame (with min/max/close)
            // reliably comes back: un-maximize first, then re-apply chrome.
            WindowState = WindowState.Normal;
            WindowStyle = WindowStyle.SingleBorderWindow;
            ResizeMode = ResizeMode.CanResize;
            if (_winBoundsSaved && !_winBounds.IsEmpty)
            {
                Left = _winBounds.X;
                Top = _winBounds.Y;
                Width = _winBounds.Width;
                Height = _winBounds.Height;
            }
        }
        if (save) AppSettings.Current.Save();
    }

    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        if (_settingsWin == null)
        {
            _settingsWin = new SettingsWindow(this);
            _settingsWin.Closed += (_, _) => _settingsWin = null;
            _settingsWin.Show();
        }
        else _settingsWin.Activate();
        Log("Settings opened.");
    }

    private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        bool ctrl = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
        bool shift = e.KeyboardDevice.Modifiers.HasFlag(ModifierKeys.Shift);
        if (ctrl && e.Key == Key.S)
        {
            SavePlace();
            e.Handled = true;
        }
        else if (ctrl && e.Key == Key.O)
        {
            OpenPlace();
            e.Handled = true;
        }
        else if (ctrl && (e.Key == Key.Z || e.Key == Key.Y) && e.OriginalSource is not TextBox)
        {
            // Ctrl+Z undo, Ctrl+Y / Ctrl+Shift+Z redo. Skipped inside text boxes
            // so the editors keep their own keystroke undo.
            if (e.Key == Key.Z && !shift) Undo();
            else Redo();
            e.Handled = true;
        }
        else if (ctrl && e.Key == Key.D && e.OriginalSource is not TextBox)
        {
            // Keep the newly-created copy selected so repeated Ctrl+D creates
            // a chain of duplicates from the last copy, regardless of which
            // editor panel currently has keyboard focus.
            Duplicate_Click(sender, e);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape && AppSettings.Current.IsBorderless)
        {
            ApplyWindowMode("Windowed");
            _settingsWin?.SyncWindowMode();
            Log("Back to windowed (Esc).");
            e.Handled = true;
        }
    }

    // ---------- color menu ----------

    private void BuildSwatches()
    {
        foreach (var pc in Viewport.PartColor.Palette)
        {
            var swatch = new Button
            {
                Width = 30,
                Height = 26,
                Margin = new Thickness(2),
                Background = new SolidColorBrush(pc.ToMediaColor()),
                BorderBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x66, 0x66, 0x66)),
                BorderThickness = new Thickness(1),
                ToolTip = pc.Name,
                Tag = pc,
            };
            swatch.Click += Swatch_Click;
            SwatchGrid.Children.Add(swatch);
        }
    }

    private void ColorMenu_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected == null)
        {
            Log("Color: select a part first.");
            StatusText.Text = "Select a part first";
            return;
        }
        SyncCustomEditor(_scene.Selected.Color);
        ColorPopup.IsOpen = true;
    }

    private void Swatch_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: Viewport.PartColor pc })
        {
            ApplyPartColor(pc.Color, pc.Name);
            ColorPopup.IsOpen = false;
        }
    }

    /// <summary>Render the hue/saturation wheel once (hue = angle, saturation = radius).</summary>
    private void BuildWheel()
    {
        const int size = 168;
        const double half = size / 2.0;
        var bmp = new System.Windows.Media.Imaging.WriteableBitmap(
            size, size, 96, 96, System.Windows.Media.PixelFormats.Bgr32, null);
        byte[] px = new byte[size * size * 4];
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            double dx = x - (half - 0.5), dy = y - (half - 0.5);
            double r = Math.Sqrt(dx * dx + dy * dy) / half;
            int i = (y * size + x) * 4;
            if (r > 1.0) { px[i] = 38; px[i + 1] = 37; px[i + 2] = 37; px[i + 3] = 255; continue; }
            double ang = Math.Atan2(-dy, dx) * 180.0 / Math.PI;
            if (ang < 0) ang += 360;
            var c = Viewport.PartColor.HsvToRgb(ang, Math.Min(r, 1.0), 1.0);
            px[i] = c.B; px[i + 1] = c.G; px[i + 2] = c.R; px[i + 3] = 255;
        }
        bmp.WritePixels(new Int32Rect(0, 0, size, size), px, size * 4, 0);
        WheelImage.Source = bmp;
    }

    private void Wheel_Down(object sender, MouseButtonEventArgs e)
    {
        WheelCanvas.CaptureMouse();
        WheelPick(e.GetPosition(WheelCanvas));
    }

    private void Wheel_Move(object sender, MouseEventArgs e)
    {
        if (WheelCanvas.IsMouseCaptured) WheelPick(e.GetPosition(WheelCanvas));
    }

    private void Wheel_Up(object sender, MouseButtonEventArgs e)
    {
        if (WheelCanvas.IsMouseCaptured) WheelCanvas.ReleaseMouseCapture();
    }

    private void WheelPick(Point p)
    {
        const double half = 84.0;
        double dx = p.X - half, dy = p.Y - half;
        double r = Math.Min(Math.Sqrt(dx * dx + dy * dy) / half, 1.0);
        double ang = Math.Atan2(-dy, dx) * 180.0 / Math.PI;
        if (ang < 0) ang += 360;
        _customH = ang;
        _customS = r;
        RefreshCustomPreview();
    }

    private void RefreshCustomPreview()
    {
        var c = Viewport.PartColor.HsvToRgb(_customH, _customS, _customV);
        _customSync = true;
        CustomPreview.Background = new SolidColorBrush(c);
        RgbBox.Text = Viewport.PartColor.ToRgbText(c);
        double rad = _customH * Math.PI / 180.0;
        double rr = _customS * 84.0;
        Canvas.SetLeft(WheelMarker, 84.0 + rr * Math.Cos(rad) - 6.0);
        Canvas.SetTop(WheelMarker, 84.0 - rr * Math.Sin(rad) - 6.0);
        _customSync = false;
    }

    private void ValueSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        // Fires during InitializeComponent (Value="100" in XAML) before HexBox exists.
        if (_customSync || !IsLoaded) return;
        _customV = ValueSlider.Value / 100.0;
        RefreshCustomPreview();
    }

    private void SyncCustomEditor(Color4 c)
    {
        var mc = System.Windows.Media.Color.FromRgb(
            PartColor.ToByte(c.R), PartColor.ToByte(c.G), PartColor.ToByte(c.B));
        Viewport.PartColor.RgbToHsv(mc, out _customH, out _customS, out _customV);
        _customSync = true;
        ValueSlider.Value = _customV * 100.0;
        _customSync = false;
        RefreshCustomPreview();
    }

    private void RgbBox_Commit(object sender, RoutedEventArgs e) => ApplyRgb();
    private void RgbBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) { ApplyRgb(); e.Handled = true; }
    }

    private void ApplyRgb()
    {
        // Accept "r, g, b" as well as hex for convenience.
        if (!Viewport.PartColor.TryParseRgb(RgbBox.Text, out var mc) &&
            !Viewport.PartColor.TryParseHex(RgbBox.Text, out mc))
        {
            RgbBox.Text = PreviewRgb();
            return;
        }
        Viewport.PartColor.RgbToHsv(mc, out _customH, out _customS, out _customV);
        _customSync = true;
        ValueSlider.Value = _customV * 100.0;
        _customSync = false;
        RefreshCustomPreview();
    }

    private string PreviewRgb()
    {
        var c = ((SolidColorBrush)CustomPreview.Background).Color;
        return Viewport.PartColor.ToRgbText(c);
    }

    private void ApplyCustom_Click(object sender, RoutedEventArgs e)
    {
        var c = ((SolidColorBrush)CustomPreview.Background).Color;
        ApplyPartColor(Viewport.PartColor.FromMediaColor(c), PreviewRgb());
        ColorPopup.IsOpen = false;
    }

    private void ApplyPartColor(Color4 c, string label)
    {
        if (_scene.Selected is not { } sel) return;
        PushUndo("Color", mergeable: false);
        sel.Color = c;
        UpdateLiveProps();
        MarkDirty();
        _needsFrame = true;
        Log($"Color → {label} on {sel.Name}.");
        StatusText.Text = $"{sel.Name}: {label}";
    }

    // ---------- material menu ----------

    private void BuildMaterials()
    {
        foreach (Viewport.MaterialKind kind in Enum.GetValues<Viewport.MaterialKind>())
        {
            var p = Viewport.MaterialParams.Of(kind);
            var btn = new Button
            {
                Margin = new Thickness(0, 2, 0, 2),
                Padding = new Thickness(8, 5, 8, 5),
                Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x3F, 0x3F, 0x46)),
                BorderBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x55, 0x55, 0x55)),
                BorderThickness = new Thickness(1),
                Foreground = Brushes.White,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Tag = kind,
                Content = new StackPanel
                {
                    Children =
                    {
                        new TextBlock { Text = kind.ToString(), FontWeight = FontWeights.SemiBold, Foreground = Brushes.White },
                        new TextBlock { Text = p.Blurb, FontSize = 11, Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xAA, 0xAA, 0xAA)) },
                    },
                },
            };
            btn.Click += Material_Click;
            MaterialList.Children.Add(btn);
        }
    }

    private void MaterialMenu_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected == null)
        {
            Log("Material: select a part first.");
            StatusText.Text = "Select a part first";
            return;
        }
        // The popup lives once in the tree: point it at whichever tab's button opened it.
        if (sender is System.Windows.UIElement anchor) MaterialPopup.PlacementTarget = anchor;
        MaterialPopup.IsOpen = true;
    }

    private void Material_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: Viewport.MaterialKind kind })
        {
            ApplyMaterial(kind);
            MaterialPopup.IsOpen = false;
        }
    }

    private void ApplyMaterial(Viewport.MaterialKind kind)
    {
        if (_scene.Selected is not { } sel) return;
        PushUndo("Material", mergeable: false);
        sel.Material = kind;
        UpdateLiveProps();
        MarkDirty();
        _needsFrame = true;
        Log($"Material → {kind} on {sel.Name}.");
        StatusText.Text = $"{sel.Name}: {kind}";
    }

    private void ApplyDecal_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected is not { } selected)
        {
            StatusText.Text = "Select a part first";
            Log("Decal: select a part first.");
            return;
        }
        selected.MigrateSingleToList();
        if (selected.Decals.Count >= Viewport.SceneObject.MaxDecals)
        {
            StatusText.Text = $"Max {Viewport.SceneObject.MaxDecals} decals per part";
            Log($"Decal: {selected.Name} already has {selected.Decals.Count} (max). Remove one first.");
            return;
        }
        var dialog = new OpenFileDialog
        {
            Title = $"Import decal image ({selected.Decals.Count + 1} of {Viewport.SceneObject.MaxDecals})",
            Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files|*.*",
            CheckFileExists = true,
        };
        if (dialog.ShowDialog(this) != true) return;
        PushUndo("Decal", mergeable: false);
        selected.Decals.Add(new Viewport.DecalLayer { Image = dialog.FileName, Face = "Front" });
        _liveRows = ObjectProperties(selected);
        SetPropertyRows(_liveRows);
        _needsFrame = true;
        Log($"Decal {selected.Decals.Count} applied to {selected.Name}: {dialog.FileName}");
        StatusText.Text = "Decal applied";
        MarkDirty();
    }

    private void ApplyText_Click(object sender, RoutedEventArgs e)
    {
        if (_scene.Selected is not { } selected)
        {
            StatusText.Text = "Select a part first";
            Log("Text: select a part first.");
            return;
        }
        if (selected.Texts.Count >= Viewport.SceneObject.MaxTexts)
        {
            StatusText.Text = $"Max {Viewport.SceneObject.MaxTexts} texts per part";
            Log($"Text: {selected.Name} already has {selected.Texts.Count} (max). Remove one first.");
            return;
        }
        PushUndo("Add text", mergeable: false);
        selected.Texts.Add(new Viewport.TextLayer { Text = "Text", Face = "Front" });
        _liveRows = ObjectProperties(selected);
        SetPropertyRows(_liveRows);
        _needsFrame = true;
        MarkDirty();
        Log($"Text {selected.Texts.Count} added to {selected.Name}.");
        StatusText.Text = "Text added";
    }

    // ---------- panels ----------

    private void ExplorerTree_Selected(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (e.NewValue is SceneNode n) ShowNode(n);
    }

    private void ShowNode(SceneNode n)
    {
        _scene.Selected = n.Tag as Viewport.SceneObject;
        if (_scene.Selected is { } so)
        {
            SelectedLabel.Text = PartLabel(so);
            _liveObj = so;
            _liveService = null;
            _liveRows = ObjectProperties(so);
            SetPropertyRows(_liveRows);
        }
        else if (n.Tag is null && n.Name is "Sun" or "Atmosphere" or "Lighting")
        {
            _liveObj = null;
            _liveService = n.Name;
            _liveRows = ServiceProperties(n.Name);
            SetPropertyRows(_liveRows);
            SelectedLabel.Text = $"{n.Name} [{n.Type}]";
        }
        else
        {
            _liveObj = null;
            _liveService = null;
            _liveRows = null;
            SelectedLabel.Text = $"{n.Name} [{n.Type}]";
            SetPropertyRows(DefaultProperties(n.Name, n.Type));
        }
        StatusText.Text = $"Selected: {n.Name}";
        SyncAnchorToggle();
    }

    private void SetPropertyRows(IEnumerable<PropertyRow> rows)
    {
        _propFull = rows.ToList();
        if (PropertiesList == null) return; // before InitializeComponent finishes
        ApplyPropertyFilter();
    }

    private void PropertiesFilter_Changed(object sender, TextChangedEventArgs e)
    {
        if (_propFilterSync) return;
        // TextChanged fires during InitializeComponent (Text="Filter" in XAML)
        // before PropertiesList exists. Skip; SetPropertyRows after init populates.
        if (PropertiesList == null) return;
        ApplyPropertyFilter();
    }

    /// <summary>Filter rows by name/category/value; recompute category headers for the visible set.</summary>
    private void ApplyPropertyFilter()
    {
        // Guard init order: filter box is declared before the list in XAML.
        if (PropertiesList == null) return;
        string q = (PropertiesFilter?.Text ?? "").Trim();
        if (q is "Filter" || q.StartsWith("🔍")) q = "";
        List<PropertyRow> visible;
        if (string.IsNullOrWhiteSpace(q))
        {
            visible = _propFull;
        }
        else
        {
            visible = _propFull.Where(r =>
                r.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                r.Category.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                r.Value.Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
        }
        string? last = null;
        foreach (var row in visible) { row.ShowCategory = row.Category != last; last = row.Category; }
        _propFilterSync = true;
        PropertiesList.ItemsSource = visible;
        if (PropHint != null)
            PropHint.Text = string.IsNullOrWhiteSpace(q)
                ? "Enter commits · Esc reverts"
                : $"{visible.Count} of {_propFull.Count} match “{q}”";
        _propFilterSync = false;
    }

    /// <summary>Refresh the live Properties rows in place (cheap: no grid rebind).</summary>
    private void UpdateLiveProps()
    {
        if (_liveObj is { } o && _liveRows != null)
        {
            foreach (var r in _liveRows)
            {
                switch (r.Name)
                {
                case "Name": r.Value = o.Name; break;
                case "Position": r.Value = PosValue(o); break;
                case "Size":
                    if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                            r.Value = o.Texts[r.TextIndex].Size.ToString("0", CultureInfo.InvariantCulture);
                    }
                    else r.Value = SizeValue(o);
                    break;
                case "Rotation": r.Value = RotValue(o); break;
                case "Shape": r.Value = o.Shape.ToString(); break;
                case "Color":
                    if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                        {
                            r.Value = o.Texts[r.TextIndex].Color;
                            r.Swatch = TextSwatch(o.Texts[r.TextIndex].Color);
                        }
                    }
                    else
                    {
                        r.Value = ColorValue(o);
                        r.Swatch = ColorBrush(o.Color);
                    }
                    break;
                case "Material": r.Value = o.Material.ToString(); break;
                case "Transparency": r.Value = o.Transparency.ToString("0.00", CultureInfo.InvariantCulture); break;
                case "Reflectance": r.Value = o.Reflectance.ToString("0.00", CultureInfo.InvariantCulture); break;
                case "CastShadow": r.Value = o.CastShadow.ToString(); break;
                case "Anchored": r.Value = o.Anchored.ToString(); break;
                case "Spawn": r.Value = o.IsSpawn.ToString(); break;
                case "Mass": r.Value = o.Mass.ToString("0.00", CultureInfo.InvariantCulture); break;
                case "CanCollide": r.Value = o.CanCollide.ToString(); break;
                case "Image":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count)
                            SyncThumbnail(r, o.Decals[r.DecalIndex].Image);
                    }
                    else SyncThumbnail(r, o.DecalImage ?? "None");
                    break;
                case "Face":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count) r.Value = o.Decals[r.DecalIndex].Face;
                    }
                    else if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count) r.Value = o.Texts[r.TextIndex].Face;
                    }
                    else r.Value = o.DecalFace;
                    break;
                case "Image Transparency":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count)
                            r.Value = o.Decals[r.DecalIndex].Transparency.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    else if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                            r.Value = o.Texts[r.TextIndex].Transparency.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    else r.Value = o.DecalTransparency.ToString("0.00", CultureInfo.InvariantCulture);
                    break;
                case "Image Blur":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count)
                            r.Value = o.Decals[r.DecalIndex].Blur.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    else if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                            r.Value = o.Texts[r.TextIndex].Blur.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    else r.Value = o.DecalBlur.ToString("0.00", CultureInfo.InvariantCulture);
                    break;
                case "Text":
                    if (r.TextIndex >= 0 && r.TextIndex < o.Texts.Count) r.Value = o.Texts[r.TextIndex].Text;
                    break;
                case "Font":
                    if (r.TextIndex >= 0 && r.TextIndex < o.Texts.Count) r.Value = o.Texts[r.TextIndex].Font;
                    break;
                case "Text Transparency":
                    if (r.TextIndex >= 0 && r.TextIndex < o.Texts.Count)
                        r.Value = o.Texts[r.TextIndex].Transparency.ToString("0.00", CultureInfo.InvariantCulture);
                    break;
                case "Text Blur":
                    if (r.TextIndex >= 0 && r.TextIndex < o.Texts.Count)
                        r.Value = o.Texts[r.TextIndex].Blur.ToString("0.00", CultureInfo.InvariantCulture);
                    break;
                case "Offset":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count)
                            r.Value = OffsetValue(o.Decals[r.DecalIndex].OffsetX, o.Decals[r.DecalIndex].OffsetY);
                    }
                    else if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                            r.Value = OffsetValue(o.Texts[r.TextIndex].OffsetX, o.Texts[r.TextIndex].OffsetY);
                    }
                    break;
                case "Scale":
                    if (r.DecalIndex >= 0)
                    {
                        if (r.DecalIndex < o.Decals.Count)
                            r.Value = o.Decals[r.DecalIndex].Scale.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    else if (r.TextIndex >= 0)
                    {
                        if (r.TextIndex < o.Texts.Count)
                            r.Value = o.Texts[r.TextIndex].Scale.ToString("0.00", CultureInfo.InvariantCulture);
                    }
                    break;
                }
            }
        }
        if (_liveObj == null && _liveService != null && _liveRows != null)
        {
            foreach (var r in _liveRows) UpdateServiceRow(r);
        }
        if (_scene.Selected != null)
            SelectedLabel.Text = PartLabel(_scene.Selected);
    }

    private static System.Windows.Media.Brush ColorBrush(Color4 c)
    {
        var mc = System.Windows.Media.Color.FromRgb(ToByte(c.R), ToByte(c.G), ToByte(c.B));
        var b = new SolidColorBrush(mc);
        b.Freeze();
        return b;
    }

    /// <summary>48px decal thumbnails, cached by path. Frozen so rows can share instances.</summary>
    private static readonly Dictionary<string, System.Windows.Media.ImageSource> _thumbCache =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>48px decal thumbnail for the Properties panel. Null when missing/unreadable.</summary>
    private static System.Windows.Media.ImageSource? LoadThumbnail(string? path)
    {
        if (string.IsNullOrWhiteSpace(path) || !System.IO.File.Exists(path)) return null;
        lock (_thumbCache)
        {
            if (_thumbCache.TryGetValue(path, out var cached)) return cached;
        }
        try
        {
            var bmp = new System.Windows.Media.Imaging.BitmapImage();
            bmp.BeginInit();
            bmp.UriSource = new Uri(path, UriKind.Absolute);
            bmp.DecodePixelWidth = 48;
            bmp.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
            bmp.CreateOptions = System.Windows.Media.Imaging.BitmapCreateOptions.IgnoreImageCache;
            bmp.EndInit();
            bmp.Freeze();
            lock (_thumbCache)
            {
                if (_thumbCache.Count > 256) _thumbCache.Clear(); // pathological sessions can't grow forever
                _thumbCache[path] = bmp;
            }
            return bmp;
        }
        catch { return null; }
    }

    /// <summary>Push a decal path into a row, reloading the thumbnail only when it changed
    /// (drag ticks call this ~30 Hz; a disk decode per tick is what made decalled drags jank).</summary>
    private static void SyncThumbnail(PropertyRow r, string path)
    {
        if (r.Thumbnail != null && r.Value == path) return;
        r.Value = path;
        r.Thumbnail = LoadThumbnail(path);
    }

    /// <summary>Rebuild Workspace children from the live scene, reusing nodes.</summary>
    private void RefreshExplorer()
    {
        var byObj = new Dictionary<Viewport.SceneObject, SceneNode>();
        foreach (var c in _workspace.Children)
            if (c.Tag is Viewport.SceneObject so) byObj[so] = c;
        _workspace.Children.Clear();
        foreach (var o in _scene.Objects)
        {
            if (o.IsAvatarFace) continue; // managed face panel: no tree node
            if (!byObj.TryGetValue(o, out var node))
                node = new SceneNode(o.Name, "Part",
                    o.IsSpawn ? "🟢" : "🟦",
                    o.IsSpawn ? null : "Icons/object.png") { Tag = o };
            node.Name = o.Name;
            _workspace.Children.Add(node);
        }
        PartsText.Text = $"{CountObjects()} objects";
    }

    private void SelectObject(Viewport.SceneObject? obj)
    {
        _scene.Selected = obj;
        _needsFrame = true; // selection pulse starts/stops
        RefreshExplorer();
        if (obj != null)
        {
            ExplorerTree.UpdateLayout();
            SelectNodeRecursive(ExplorerTree, obj);
        }
        else
        {
            _liveObj = null;
            _liveService = null;
            _liveRows = null;
            SelectedLabel.Text = "Nothing selected";
            SetPropertyRows(DefaultProperties("Nothing", "None"));
            SyncAnchorToggle();
        }
    }

    private bool SelectNodeRecursive(ItemsControl parent, Viewport.SceneObject obj)
    {
        foreach (var item in parent.Items)
        {
            if (item is SceneNode n && ReferenceEquals(n.Tag, obj))
            {
                if (parent.ItemContainerGenerator.ContainerFromItem(item) is TreeViewItem tvi)
                {
                    tvi.BringIntoView();
                    tvi.IsSelected = true;
                    return true;
                }
                return false;
            }
            if (parent.ItemContainerGenerator.ContainerFromItem(item) is TreeViewItem container)
            {
                container.IsExpanded = true;
                container.UpdateLayout();
                if (SelectNodeRecursive(container, obj)) return true;
            }
        }
        return false;
    }

    // ---------- editable properties (write back to the live object) ----------

    private void PropertiesGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
    {
        if (e.Row.Item is PropertyRow { Name: "Image" } row && _liveObj is { } imageTarget)
        {
            var dialog = new OpenFileDialog { Title = "Import decal image", Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files|*.*", CheckFileExists = true };
            if (dialog.ShowDialog(this) == true)
            {
                if (row.DecalIndex >= 0 && row.DecalIndex < imageTarget.Decals.Count)
                    imageTarget.Decals[row.DecalIndex].Image = dialog.FileName;
                else
                {
                    imageTarget.MigrateSingleToList();
                    if (imageTarget.Decals.Count < Viewport.SceneObject.MaxDecals)
                        imageTarget.Decals.Add(new Viewport.DecalLayer { Image = dialog.FileName, Face = "Front" });
                }
                _liveRows = ObjectProperties(imageTarget);
                SetPropertyRows(_liveRows);
            }
            _needsFrame = true;
            e.Cancel = true;
            return;
        }
        // Only live object values are editable (Class fixed, service rows display-only).
        if (_liveObj == null || e.Row.Item is not PropertyRow r || r.Name is "Class")
            e.Cancel = true;
    }

    private void PropertiesGrid_PreparingCellForEdit(object sender, DataGridPreparingCellForEditEventArgs e)
    {
        if (e.Row.Item is not PropertyRow { IsChoice: true }) return;
        // The normal DataGrid click is consumed to enter edit mode. Explicitly
        // open the enum selector once that editor has been created.
        Dispatcher.BeginInvoke(() =>
        {
            var combo = FindVisualChild<ComboBox>(e.EditingElement);
            if (combo != null) combo.IsDropDownOpen = true;
        }, System.Windows.Threading.DispatcherPriority.Input);
    }

    private static T? FindVisualChild<T>(DependencyObject? parent) where T : DependencyObject
    {
        if (parent == null) return null;
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T result) return result;
            if (FindVisualChild<T>(child) is { } nested) return nested;
        }
        return null;
    }

    private void PropertiesGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.EditAction != DataGridEditAction.Commit) return;
        if (_liveObj is not { } o || e.Row.Item is not PropertyRow r) return;
        string text = e.EditingElement is TextBox editor
            ? editor.Text
            : r.Value;
        bool ok = r.DecalIndex >= 0 ? ApplyDecalEdit(o, r.DecalIndex, r.Name, text)
            : r.TextIndex >= 0 ? ApplyTextEdit(o, r.TextIndex, r.Name, text)
            : ApplyPropertyEdit(o, r.Name, text);
        if (!ok)
            Log($"Invalid {r.Name}: kept {r.Value}.");
        if (r.Name == "Name") SyncNodeName(o);
        if (ok)
        {
            // Live bodies follow their objects while playing.
            if (_physics.Simulating)
            {
                switch (r.Name)
                {
                    case "Position": _physics.Teleport(o); break;
                    case "Rotation": o.ComposeOrientation(); _physics.Teleport(o); break;
                    case "Size":
                    case "Shape":
                    case "Mass":
                    case "Anchored": _physics.RecreateBody(o); break;
                    case "CanCollide":
                        if (o.CanCollide) _physics.RecreateBody(o);
                        else _physics.RemoveBody(o);
                        break;
                }
            }
            if (r.Name is "Position" or "Size" or "Rotation" or "Shape") _scene.InvalidateShadows();
            _needsFrame = true; // edited visuals need a present
        }
        // Deferred past the grid's own commit so canonical formatting wins.
        Dispatcher.BeginInvoke(UpdateLiveProps, System.Windows.Threading.DispatcherPriority.Background);
    }

    private void PropertyText_LostFocus(object sender, RoutedEventArgs e)
    {
        if (_propFilterSync) return;
        if (sender is FrameworkElement { DataContext: PropertyRow row }) CommitProperty(row);
    }

    private void PropertyText_KeyDown(object sender, KeyEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: PropertyRow row }) return;
        if (e.Key == Key.Enter) { CommitProperty(row); e.Handled = true; }
        else if (e.Key == Key.Escape) { UpdateLiveProps(); e.Handled = true; }
    }

    private void PropertyBoolean_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: PropertyRow row }) CommitProperty(row);
    }

    private void PropertyChoice_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_propFilterSync || !IsLoaded) return;
        if (sender is FrameworkElement { DataContext: PropertyRow row } && e.AddedItems.Count > 0) CommitProperty(row);
    }

    private void PropertyImage_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: PropertyRow row } || _liveObj is not { } o) return;
        if (row.Name != "Image") return;
        var dialog = new OpenFileDialog { Title = "Import decal image", Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files|*.*", CheckFileExists = true };
        if (dialog.ShowDialog(this) != true) return;
        if (row.DecalIndex >= 0)
        {
            if (row.DecalIndex >= o.Decals.Count) return;
            PushUndo("Decal", mergeable: false);
            o.Decals[row.DecalIndex].Image = dialog.FileName;
            row.Value = dialog.FileName;
            row.Thumbnail = LoadThumbnail(dialog.FileName);
            Log($"Decal {row.DecalIndex + 1} image replaced on {o.Name}: {dialog.FileName}");
        }
        else
        {
            PushUndo("Decal", mergeable: false);
            o.DecalImage = dialog.FileName;
            row.Value = dialog.FileName;
            row.Thumbnail = LoadThumbnail(dialog.FileName);
            // New decal means new rows (Face/Transparency/Blur appear): rebuild.
            _liveRows = ObjectProperties(o);
            SetPropertyRows(_liveRows);
            Log($"Decal applied to {o.Name}: {dialog.FileName}");
        }
        StatusText.Text = "Decal applied";
        MarkDirty();
        _needsFrame = true;
    }

    /// <summary>Add / Remove decal + text buttons in the Properties panel.</summary>
    private void PropertyAction_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: PropertyRow row } || _liveObj is not { } o) return;
        if (row.Name == "Add decal")
        {
            o.MigrateSingleToList();
            if (o.Decals.Count >= Viewport.SceneObject.MaxDecals)
            {
                StatusText.Text = $"Max {Viewport.SceneObject.MaxDecals} decals per part";
                Log($"Decal: {o.Name} already has {o.Decals.Count} (max). Remove one first.");
                return;
            }
            var dialog = new OpenFileDialog
            {
                Title = $"Import decal image ({o.Decals.Count + 1} of {Viewport.SceneObject.MaxDecals})",
                Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files|*.*",
                CheckFileExists = true,
            };
            if (dialog.ShowDialog(this) != true) return;
            PushUndo("Add decal", mergeable: false);
            o.Decals.Add(new Viewport.DecalLayer { Image = dialog.FileName, Face = "Front" });
            _liveRows = ObjectProperties(o);
            SetPropertyRows(_liveRows);
            _needsFrame = true;
            Log($"Decal {o.Decals.Count} applied to {o.Name}: {dialog.FileName}");
            StatusText.Text = "Decal applied";
            MarkDirty();
        }
        else if (row.Name == "Remove" && (row.DecalIndex >= 0 || row.TextIndex >= 0))
        {
            if (row.DecalIndex >= 0)
            {
                if (row.DecalIndex >= o.Decals.Count) return;
                PushUndo("Remove decal", mergeable: false);
                o.Decals.RemoveAt(row.DecalIndex);
                Log($"Decal {row.DecalIndex + 1} removed from {o.Name} ({o.Decals.Count} left).");
            }
            else
            {
                if (row.TextIndex >= o.Texts.Count) return;
                PushUndo("Remove text", mergeable: false);
                o.Texts.RemoveAt(row.TextIndex);
                Log($"Text {row.TextIndex + 1} removed from {o.Name} ({o.Texts.Count} left).");
            }
            _liveRows = ObjectProperties(o);
            SetPropertyRows(_liveRows);
            _needsFrame = true;
            MarkDirty();
            StatusText.Text = "Removed";
        }
        else if (row.Name == "Add text")
        {
            if (o.Texts.Count >= Viewport.SceneObject.MaxTexts)
            {
                StatusText.Text = $"Max {Viewport.SceneObject.MaxTexts} texts per part";
                Log($"Text: {o.Name} already has {o.Texts.Count} (max). Remove one first.");
                return;
            }
            PushUndo("Add text", mergeable: false);
            o.Texts.Add(new Viewport.TextLayer { Text = "Text", Face = "Front" });
            _liveRows = ObjectProperties(o);
            SetPropertyRows(_liveRows);
            _needsFrame = true;
            MarkDirty();
            Log($"Text {o.Texts.Count} added to {o.Name}.");
            StatusText.Text = "Text added";
        }
    }

    private void PropertySlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_propFilterSync || !IsLoaded) return;
        if (sender is not FrameworkElement { DataContext: PropertyRow row }) return;
        if (_liveObj == null || row.Type != "number") return;
        // Binding already pushed the rounded "0.00" string into row.Value; commit it live.
        CommitProperty(row);
    }

    private void PropertySwatch_Click(object sender, MouseButtonEventArgs e)
    {
        if (_scene.Selected == null)
        {
            Log("Color: select a part first.");
            StatusText.Text = "Select a part first";
            return;
        }
        // Open the full color picker at the clicked swatch (the popup lives once
        // in the tree, anchored to the ribbon button by default).
        if (sender is System.Windows.UIElement anchor) ColorPopup.PlacementTarget = anchor;
        SyncCustomEditor(_scene.Selected.Color);
        // Deferred past the in-progress click: a StaysOpen=False popup opened
        // synchronously inside MouseDown closes again on the matching MouseUp.
        Dispatcher.BeginInvoke(() => ColorPopup.IsOpen = true,
            System.Windows.Threading.DispatcherPriority.Background);
    }

    private void CommitProperty(PropertyRow row)
    {
        if (_liveObj == null && _liveService != null)
        {
            CommitServiceProperty(row);
            return;
        }
        if (_liveObj is not { } o || row.Name is "Class" or "Image") return;
        if (row.Type == "action") return;
        var before = CaptureState(row.Name);
        before.MergeKey = $"{row.Name}#{_scene.Objects.IndexOf(o)}";
        bool ok = row.DecalIndex >= 0 ? ApplyDecalEdit(o, row.DecalIndex, row.Name, row.Value)
            : row.TextIndex >= 0 ? ApplyTextEdit(o, row.TextIndex, row.Name, row.Value)
            : ApplyPropertyEdit(o, row.Name, row.Value);
        if (!ok)
        {
            Log($"Invalid {row.Name}: kept {DisplayRowValue(o, row)}.");
            StatusText.Text = $"Invalid {row.Name}";
            UpdateLiveProps();
            return;
        }
        PushCaptured(before, mergeable: !row.IsBoolean);
        if (row.Name == "Name") SyncNodeName(o);
        if (row.Name == "Spawn")
        {
            SyncNodeIcon(o);
            SelectedLabel.Text = PartLabel(o);
        }
        MarkDirty();
        if (row.Name == "Color")
        {
            row.Swatch = ColorBrush(o.Color);
            SyncCustomEditor(o.Color);
        }
        if (_physics.Simulating)
        {
            if (row.Name is "Size" or "Shape" or "Anchored" or "Mass") _physics.RecreateBody(o);
            else if (row.Name == "CanCollide")
            {
                if (o.CanCollide) _physics.RecreateBody(o); // ghost -> solid (no body yet)
                else _physics.RemoveBody(o); // solid -> ghost
            }
            else if (row.Name is "Position" or "Rotation") { if (row.Name == "Rotation") o.ComposeOrientation(); _physics.Teleport(o); }
        }
        if (row.Name is "Position" or "Size" or "Rotation" or "Shape") _scene.InvalidateShadows();
        if (row.Name is "Transparency" or "CastShadow" or "Material") _scene.InvalidateShadows(); // caster set changed
        if (row.Name == "Shape") RefreshExplorerShape(o);
        _needsFrame = true;
        UpdateLiveProps();
    }

    private static string DisplayRowValue(Viewport.SceneObject o, PropertyRow row)
    {
        if (row.DecalIndex >= 0)
        {
            if (row.DecalIndex >= o.Decals.Count) return "";
            var d = o.Decals[row.DecalIndex];
            return row.Name switch
            {
                "Face" => d.Face,
                "Image Transparency" => d.Transparency.ToString("0.00", CultureInfo.InvariantCulture),
                "Image Blur" => d.Blur.ToString("0.00", CultureInfo.InvariantCulture),
                "Offset" => OffsetValue(d.OffsetX, d.OffsetY),
                "Scale" => d.Scale.ToString("0.00", CultureInfo.InvariantCulture),
                _ => "",
            };
        }
        if (row.TextIndex >= 0)
        {
            if (row.TextIndex >= o.Texts.Count) return "";
            var t = o.Texts[row.TextIndex];
            return row.Name switch
            {
                "Text" => t.Text,
                "Face" => t.Face,
                "Font" => t.Font,
                "Size" => t.Size.ToString("0", CultureInfo.InvariantCulture),
                "Color" => t.Color,
                "Text Transparency" => t.Transparency.ToString("0.00", CultureInfo.InvariantCulture),
                "Text Blur" => t.Blur.ToString("0.00", CultureInfo.InvariantCulture),
                "Offset" => OffsetValue(t.OffsetX, t.OffsetY),
                "Scale" => t.Scale.ToString("0.00", CultureInfo.InvariantCulture),
                _ => "",
            };
        }
        return row.Name switch
        {
            "Name" => o.Name,
            "Position" => PosValue(o),
            "Size" => SizeValue(o),
            "Rotation" => RotValue(o),
            "Shape" => o.Shape.ToString(),
            "Color" => ColorValue(o),
            "Material" => o.Material.ToString(),
            "Transparency" => o.Transparency.ToString("0.00", CultureInfo.InvariantCulture),
            "Reflectance" => o.Reflectance.ToString("0.00", CultureInfo.InvariantCulture),
            "CastShadow" => o.CastShadow.ToString(),
            "Anchored" => o.Anchored.ToString(),
            "Spawn" => o.IsSpawn.ToString(),
            "Mass" => o.Mass.ToString("0.00", CultureInfo.InvariantCulture),
            "CanCollide" => o.CanCollide.ToString(),
            _ => "",
        };
    }

    /// <summary>Refresh the Explorer icon when the shape changes (same node, new glyph).</summary>
    private void RefreshExplorerShape(Viewport.SceneObject o)
    {
        SyncNodeIcon(o);
        RefreshExplorer();
        ExplorerTree.UpdateLayout();
        SelectNodeRecursive(ExplorerTree, o);
    }

    /// <summary>Parse one edited text-layer value back into the object. False = rejected.</summary>
    private static bool ApplyTextEdit(Viewport.SceneObject o, int index, string name, string text)
    {
        if (index < 0 || index >= o.Texts.Count) return false;
        var t = o.Texts[index];
        switch (name)
        {
            case "Text":
                if (string.IsNullOrEmpty(text) || text.Length > 200) return false;
                t.Text = text;
                return true;
            case "Face":
                if (text.Trim() is not ("Front" or "Back" or "Left" or "Right" or "Top" or "Bottom")) return false;
                t.Face = text.Trim();
                return true;
            case "Font":
                if (!Viewport.TextFonts.Exists(text)) return false;
                t.Font = text.Trim();
                return true;
            case "Size":
                if (!TryFloat(text, out var size)) return false;
                t.Size = Math.Clamp(size, 8f, 256f);
                return true;
            case "Color":
                if (!Viewport.PartColor.TryParseRgb(text, out var mc) &&
                    !Viewport.PartColor.TryParseHex(text, out mc)) return false;
                t.Color = Viewport.PartColor.ToRgbText(mc);
                return true;
            case "Text Transparency":
                if (!TryFloat(text, out var textTransparency)) return false;
                t.Transparency = Math.Clamp(textTransparency, 0f, 1f);
                return true;
            case "Text Blur":
                if (!TryFloat(text, out var textBlur)) return false;
                t.Blur = Math.Clamp(textBlur, 0f, 1f);
                return true;
            case "Offset":
                if (!TryV2(text, out var tox, out var toy)) return false;
                t.OffsetX = Math.Clamp(tox, -1f, 1f);
                t.OffsetY = Math.Clamp(toy, -1f, 1f);
                return true;
            case "Scale":
                if (!TryFloat(text, out var tscale)) return false;
                t.Scale = Math.Clamp(tscale, 0.05f, 1f);
                return true;
            default:
                return false;
        }
    }

    /// <summary>Parse one edited decal-layer value back into the object. False = rejected.</summary>
    private static bool ApplyDecalEdit(Viewport.SceneObject o, int index, string name, string text)
    {
        if (index < 0 || index >= o.Decals.Count) return false;
        var d = o.Decals[index];
        switch (name)
        {
            case "Face":
                if (text.Trim() is not ("Front" or "Back" or "Left" or "Right" or "Top" or "Bottom")) return false;
                d.Face = text.Trim();
                return true;
            case "Image Transparency":
                if (!TryFloat(text, out var transparency)) return false;
                d.Transparency = Math.Clamp(transparency, 0f, 1f);
                return true;
            case "Image Blur":
                if (!TryFloat(text, out var blur)) return false;
                d.Blur = Math.Clamp(blur, 0f, 1f);
                return true;
            case "Offset":
                if (!TryV2(text, out var ox, out var oy)) return false;
                d.OffsetX = Math.Clamp(ox, -1f, 1f);
                d.OffsetY = Math.Clamp(oy, -1f, 1f);
                return true;
            case "Scale":
                if (!TryFloat(text, out var scale)) return false;
                d.Scale = Math.Clamp(scale, 0.05f, 1f);
                return true;
            default:
                return false;
        }
    }

    /// <summary>Commit one Lighting/Sun/Atmosphere row. False = rejected.</summary>
    private bool ApplyServiceEdit(PropertyRow row)
    {
        if (_liveService == "Sun")
            switch (row.Name)
            {
                case "Direction":
                    if (!TryV3(row.Value, out var d) || d.LengthSquared < 1e-8f) return false;
                    _scene.SunDirection = d; // setter retargets light + shadows
                    return true;
                case "Color":
                    if (!Viewport.PartColor.TryParseRgb(row.Value, out var mc) &&
                        !Viewport.PartColor.TryParseHex(row.Value, out mc)) return false;
                    _scene.SunColor = new Vector3(mc.R / 255f, mc.G / 255f, mc.B / 255f);
                    return true;
                case "Intensity":
                    if (!TryFloat(row.Value, out var i)) return false;
                    _scene.SunIntensity = Math.Clamp(i, 0f, 2f);
                    return true;
                case "Shadows":
                    if (bool.TryParse(row.Value.Trim(), out bool sh)) { ApplyShadows(sh); return true; }
                    if (row.Value.Trim() is "1") { ApplyShadows(true); return true; }
                    if (row.Value.Trim() is "0") { ApplyShadows(false); return true; }
                    return false;
            }
        else if (_liveService == "Atmosphere")
            switch (row.Name)
            {
                case "Fog Density":
                    if (!TryFloat(row.Value, out var fog)) return false;
                    ApplyFog(Math.Clamp(fog, 0f, 0.05f)); // persisted like Settings
                    return true;
                case "Fog Color":
                    if (!Viewport.PartColor.TryParseRgb(row.Value, out var fmc) &&
                        !Viewport.PartColor.TryParseHex(row.Value, out fmc)) return false;
                    _scene.FogColor = new Vector3(fmc.R / 255f, fmc.G / 255f, fmc.B / 255f);
                    return true;
                case "Haze":
                    if (!TryFloat(row.Value, out var haze)) return false;
                    _scene.SkyHaze = Math.Clamp(haze, 0f, 0.05f);
                    return true;
            }
        else if (_liveService == "Lighting" && row.Name == "Ambient")
        {
            if (!TryFloat(row.Value, out var amb)) return false;
            _scene.AmbientBoost = Math.Clamp(amb, 0f, 2f);
            return true;
        }
        return false;
    }

    private void CommitServiceProperty(PropertyRow row)
    {
        if (row.Type == "action") return;
        var before = CaptureState(row.Name);
        if (!ApplyServiceEdit(row))
        {
            Log($"Invalid {row.Name}: kept {DisplayServiceValue(row)}.");
            StatusText.Text = $"Invalid {row.Name}";
            UpdateLiveProps();
            return;
        }
        if (row.Name is "Color") row.Swatch = BrushOf(_scene.SunColor);
        if (row.Name is "Fog Color") row.Swatch = BrushOf(_scene.FogColor);
        PushCaptured(before, mergeable: !row.IsBoolean);
        MarkDirty(); // sun/atmosphere edits are place content
        _needsFrame = true; // new lighting needs a present
        UpdateLiveProps();
    }

    private string DisplayServiceValue(PropertyRow row) => (_liveService, row.Name) switch
    {
        ("Sun", "Direction") => DirValue(_scene.SunDirection),
        ("Sun", "Color") => ColorValueVec(_scene.SunColor),
        ("Sun", "Intensity") => _scene.SunIntensity.ToString("0.00", CultureInfo.InvariantCulture),
        ("Sun", "Shadows") => _scene.ShadowsEnabled.ToString(),
        ("Atmosphere", "Fog Density") => _scene.FogDensity.ToString("0.000", CultureInfo.InvariantCulture),
        ("Atmosphere", "Fog Color") => ColorValueVec(_scene.FogColor),
        ("Atmosphere", "Haze") => _scene.SkyHaze.ToString("0.000", CultureInfo.InvariantCulture),
        ("Lighting", "Ambient") => _scene.AmbientBoost.ToString("0.00", CultureInfo.InvariantCulture),
        _ => "",
    };

    /// <summary>Refresh one service row in place (no rebind).</summary>
    private void UpdateServiceRow(PropertyRow r)
    {
        r.Value = DisplayServiceValue(r);
        if (r.Name is "Color") r.Swatch = BrushOf(_scene.SunColor);
        else if (r.Name is "Fog Color") r.Swatch = BrushOf(_scene.FogColor);
    }

    private List<PropertyRow> ServiceProperties(string service)
    {
        List<PropertyRow> rows = service switch
        {
            "Sun" => new List<PropertyRow>
            {
            new PropertyRow { Category = "Sun", Name = "Direction", Type = "vector", Value = "",
                Description = "Sun direction, e.g. 0.50, 0.80, 0.60. Retargets the key light, sky sun and shadow frustum." },
            new PropertyRow { Category = "Sun", Name = "Color", Type = "color", Value = "",
                Description = "Sunlight tint for parts and sky. RGB 0-255 (e.g. 255, 247, 235) or #hex." },
            new PropertyRow { Category = "Sun", Name = "Intensity", Value = "",
                Description = "Sunlight multiplier 0-2 (1 = default)." },
            new PropertyRow { Category = "Sun", Name = "Shadows", Type = "bool", Value = "",
                Description = "Sun shadows (same switch as View > Shadows)." },
        },
        "Atmosphere" => new List<PropertyRow>
        {
            new PropertyRow { Category = "Atmosphere", Name = "Fog Density", Value = "",
                Description = "Exponential fog 0-0.05 (0 disables). Same as Settings > Fog." },
            new PropertyRow { Category = "Atmosphere", Name = "Fog Color", Type = "color", Value = "",
                Description = "Horizon haze and background clear color." },
            new PropertyRow { Category = "Atmosphere", Name = "Haze", Value = "",
                Description = "Sky haze (Mie scattering) 0-0.05. Higher = milkier horizon." },
        },
        _ => new List<PropertyRow>
        {
            new PropertyRow { Category = "Lighting", Name = "Ambient", Value = "",
                Description = "Sky/ground ambient multiplier 0-2 (1 = default)." },
        },
        };
        // _liveService is already set by the caller, so values resolve immediately.
        foreach (var r in rows) UpdateServiceRow(r);
        return rows;
    }

    private static string DirValue(Vector3 v) =>
        string.Format(CultureInfo.InvariantCulture, "{0:0.00}, {1:0.00}, {2:0.00}", v.X, v.Y, v.Z);

    private static string ColorValueVec(Vector3 c) =>
        $"{ToByte(c.X)}, {ToByte(c.Y)}, {ToByte(c.Z)}";

    private static System.Windows.Media.Brush BrushOf(Vector3 c)
    {
        var b = new SolidColorBrush(System.Windows.Media.Color.FromRgb(ToByte(c.X), ToByte(c.Y), ToByte(c.Z)));
        b.Freeze();
        return b;
    }

    /// <summary>Parse one edited property value back into the object. False = rejected.</summary>
    private static bool ApplyPropertyEdit(Viewport.SceneObject o, string name, string text)
    {
        switch (name)
        {
            case "Name":
                if (string.IsNullOrWhiteSpace(text)) return false;
                o.Name = text.Trim();
                return true;
            case "Position":
                if (!TryV3(text, out var p)) return false;
                o.Position = p;
                return true;
            case "Size":
                if (!TryV3(text, out var s)) return false;
                o.Size = new Vector3(
                    Math.Max(s.X, 0.05f), Math.Max(s.Y, 0.05f), Math.Max(s.Z, 0.05f));
                return true;
            case "Rotation":
                if (!TryV3(text.Replace("°", ""), out var rot)) return false;
                o.Rotation = rot;
                o.ComposeOrientation();
                return true;
            case "Shape":
                if (!Enum.TryParse<ShapeKind>(text, out var shape)) return false;
                o.Shape = shape;
                return true;
            case "Color":
                if (!Viewport.PartColor.TryParseRgb(text, out var mc) &&
                    !Viewport.PartColor.TryParseHex(text, out mc)) return false;
                o.Color = Viewport.PartColor.FromMediaColor(mc);
                return true;
            case "Anchored":
                if (bool.TryParse(text.Trim(), out bool anch)) { o.Anchored = anch; return true; }
                if (text.Trim() is "1") { o.Anchored = true; return true; }
                if (text.Trim() is "0") { o.Anchored = false; return true; }
                return false;
            case "Spawn":
                if (bool.TryParse(text.Trim(), out bool sp)) { o.IsSpawn = sp; return true; }
                if (text.Trim() is "1") { o.IsSpawn = true; return true; }
                if (text.Trim() is "0") { o.IsSpawn = false; return true; }
                return false;
            case "Mass":
                if (!TryFloat(text, out var mass)) return false;
                o.Mass = Math.Clamp(mass, 0.01f, 100f);
                return true;
            case "CanCollide":
                if (bool.TryParse(text.Trim(), out bool coll)) { o.CanCollide = coll; return true; }
                if (text.Trim() is "1") { o.CanCollide = true; return true; }
                if (text.Trim() is "0") { o.CanCollide = false; return true; }
                return false;
            case "Image Transparency":
                if (!TryFloat(text, out var transparency)) return false;
                o.DecalTransparency = Math.Clamp(transparency, 0f, 1f);
                return true;
            case "Image Blur":
                if (!TryFloat(text, out var blur)) return false;
                o.DecalBlur = Math.Clamp(blur, 0f, 1f);
                return true;
            case "Material":
                if (!Enum.TryParse<Viewport.MaterialKind>(text, out var material)) return false;
                o.Material = material;
                return true;
            case "Transparency":
                if (!TryFloat(text, out var partTransparency)) return false;
                o.Transparency = Math.Clamp(partTransparency, 0f, 1f);
                return true;
            case "Reflectance":
                if (!TryFloat(text, out var reflectance)) return false;
                o.Reflectance = Math.Clamp(reflectance, 0f, 1f);
                return true;
            case "CastShadow":
                if (bool.TryParse(text.Trim(), out bool cast)) { o.CastShadow = cast; return true; }
                if (text.Trim() is "1") { o.CastShadow = true; return true; }
                if (text.Trim() is "0") { o.CastShadow = false; return true; }
                return false;
            case "Face":
                if (text.Trim() is not ("Front" or "Back" or "Left" or "Right" or "Top" or "Bottom")) return false;
                o.DecalFace = text.Trim();
                return true;
            default:
                return false;
        }
    }

    private void SyncNodeName(Viewport.SceneObject o)
    {
        foreach (var c in _workspace.Children)
            if (ReferenceEquals(c.Tag, o)) { c.Name = o.Name; break; }
        SelectedLabel.Text = PartLabel(o);
        StatusText.Text = $"Renamed: {o.Name}";
    }

    private static string PartLabel(Viewport.SceneObject o) =>
        $"{o.Name} [{o.Shape} · {o.Material}{(o.IsSpawn ? " · Spawn" : "")}]";

    /// <summary>Match a tree node icon to its part (spawn pads get the green dot).</summary>
    private void SyncNodeIcon(Viewport.SceneObject o)
    {
        foreach (var c in _workspace.Children)
            if (ReferenceEquals(c.Tag, o))
            {
                if (o.IsSpawn) { c.Icon = "🟢"; c.IconPath = null; }
                else { c.Icon = "🟦"; c.IconPath = "Icons/object.png"; }
                break;
            }
    }

    private static bool TryFloat(string s, out float f) =>
        float.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out f);

    private static bool TryV3(string text, out Vector3 v)
    {
        v = Vector3.Zero;
        var parts = text.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 3) return false;
        float[] f = new float[3];
        for (int i = 0; i < 3; i++)
            if (!TryFloat(parts[i], out f[i])) return false;
        v = new Vector3(f[0], f[1], f[2]);
        return true;
    }

    private static List<PropertyRow> ObjectProperties(Viewport.SceneObject o)
    {
        return new List<PropertyRow>
        {
            new PropertyRow { Category = "General", Name = "Name", Value = o.Name,
                Description = "Object name (must not be empty). Shows in Explorer." },
            new PropertyRow { Category = "General", Name = "Class", Value = "Part", Type = "readonly",
                Description = "Built-in class. Parts are the only editable class." },
            new PropertyRow
            {
                Category = "General", Name = "Shape", Type = "enum", Value = o.Shape.ToString(),
                Choices = Enum.GetNames<ShapeKind>(),
                Description = "Part mesh. Changes geometry and Explorer icon.",
            },
            new PropertyRow { Category = "Transform", Name = "Position", Type = "vector", Value = PosValue(o),
                Description = "Center in studs. Format: x, y, z  (e.g. 0, 1, 0)" },
            new PropertyRow { Category = "Transform", Name = "Size", Type = "vector", Value = SizeValue(o),
                Description = "Size in studs, min 0.05 each. Format: x, y, z" },
            new PropertyRow { Category = "Transform", Name = "Rotation", Type = "vector", Value = RotValue(o),
                Description = "XYZ euler degrees. Format: x, y, z°  (e.g. 0, 45, 0°)" },
            new PropertyRow { Category = "Appearance", Name = "Color", Type = "color", Value = ColorValue(o),
                Swatch = ColorBrush(o.Color),
                Description = "Part color. RGB 0-255 (e.g. 38, 128, 242) or #hex. Click the swatch for the picker." },
            new PropertyRow
            {
                Category = "Appearance", Name = "Material", Type = "enum", Value = o.Material.ToString(),
                Choices = Enum.GetNames<Viewport.MaterialKind>(),
                Description = "Surface preset: gloss, metalness, transparency, glow.",
            },
            new PropertyRow { Category = "Appearance", Name = "Transparency", Type = "number",
                Value = o.Transparency.ToString("0.00", CultureInfo.InvariantCulture),
                Description = "Extra transparency 0-1 on top of the material. 1 = invisible." },
            new PropertyRow { Category = "Appearance", Name = "Reflectance", Type = "number",
                Value = o.Reflectance.ToString("0.00", CultureInfo.InvariantCulture),
                Description = "Mirror-like sky/sun reflection 0-1 (faked, no env map)." },
            new PropertyRow { Category = "Appearance", Name = "CastShadow", Type = "bool", Value = o.CastShadow.ToString(),
                Description = "Off = invisible to the sun shadow map (still receives shadows)." },
            new PropertyRow { Category = "Behavior", Name = "Anchored", Type = "bool", Value = o.Anchored.ToString(),
                Description = "Anchored parts don't fall in Play mode (static bodies)." },
            new PropertyRow { Category = "Behavior", Name = "Spawn", Type = "bool", Value = o.IsSpawn.ToString(),
                Description = "Spawn point: the avatar starts here on Play (first one wins)." },
            new PropertyRow { Category = "Behavior", Name = "Mass", Value = o.Mass.ToString("0.00", CultureInfo.InvariantCulture),
                Description = "How heavy the part is in Play mode, 0.01-100 (1 = default). All masses fall the same." },
            new PropertyRow { Category = "Behavior", Name = "CanCollide", Type = "bool", Value = o.CanCollide.ToString(),
                Description = "Off = ghost: renders and selects, but falls through everything." },
        }.Concat(DecalProperties(o)).Concat(TextProperties(o)).ToList();
    }

    private static IReadOnlyList<string>? _fontNames;

    /// <summary>Installed system font families for the text Font dropdown.</summary>
    private static IReadOnlyList<string> FontNames() => _fontNames ??=
        System.Drawing.FontFamily.Families.Select(f => f.Name)
            .OrderBy(n => n, StringComparer.OrdinalIgnoreCase).ToList();

    private static IEnumerable<PropertyRow> TextProperties(Viewport.SceneObject o)
    {
        for (int i = 0; i < o.Texts.Count; i++)
        {
            var t = o.Texts[i];
            string cat = $"Text {i + 1}";
            yield return new PropertyRow { Category = cat, Name = "Text", Value = t.Text,
                TextIndex = i, Description = $"Text {i + 1} content (up to 200 characters)." };
            yield return new PropertyRow
            {
                Category = cat, Name = "Face", Type = "enum", Value = t.Face, TextIndex = i,
                Choices = new[] { "Front", "Back", "Left", "Right", "Top", "Bottom" },
                Description = $"Which part face shows text {i + 1}.",
            };
            yield return new PropertyRow
            {
                Category = cat, Name = "Font", Type = "enum", Value = t.Font, TextIndex = i,
                Choices = FontNames(),
                Description = $"System font for text {i + 1}.",
            };
            yield return new PropertyRow { Category = cat, Name = "Size", Value = t.Size.ToString("0", CultureInfo.InvariantCulture),
                TextIndex = i, Description = $"Texture pixels 8-256 for text {i + 1} (per-face resolution)." };
            yield return new PropertyRow { Category = cat, Name = "Color", Type = "color", Value = t.Color,
                TextIndex = i, Swatch = TextSwatch(t.Color),
                Description = $"Text {i + 1} color. RGB 0-255 (e.g. 255, 255, 255) or #hex." };
            yield return new PropertyRow { Category = cat, Name = "Text Transparency", Type = "number",
                Value = t.Transparency.ToString("0.00", CultureInfo.InvariantCulture), TextIndex = i,
                Description = "0 = opaque, 1 = invisible. Drag the slider or type 0-1." };
            yield return new PropertyRow { Category = cat, Name = "Text Blur", Type = "number",
                Value = t.Blur.ToString("0.00", CultureInfo.InvariantCulture), TextIndex = i,
                Description = "Softens the text. 0 = sharp, 1 = max blur." };
            yield return new PropertyRow { Category = cat, Name = "Offset", Value = OffsetValue(t.OffsetX, t.OffsetY),
                TextIndex = i, Description = $"Text {i + 1} center on the face, x right / y up (-1 to 1). 0, 0 = centered." };
            yield return new PropertyRow { Category = cat, Name = "Scale", Type = "number",
                Value = t.Scale.ToString("0.00", CultureInfo.InvariantCulture), TextIndex = i,
                Description = $"Fraction of the face text {i + 1} covers. 1 = full face." };
            yield return new PropertyRow { Category = cat, Name = "Remove", Type = "action",
                Value = "Remove", TextIndex = i,
                Description = $"Remove text {i + 1} from this part." };
        }
        if (o.Texts.Count < Viewport.SceneObject.MaxTexts)
            yield return new PropertyRow { Category = "Text", Name = "Add text", Type = "action",
                Value = o.Texts.Count == 0 ? "+ Add text" : "+ Add another",
                Description = $"Add rendered text (up to {Viewport.SceneObject.MaxTexts} per part, any face)." };
    }

    private static System.Windows.Media.Brush TextSwatch(string color)
    {
        if (!Viewport.PartColor.TryParseRgb(color, out var mc) &&
            !Viewport.PartColor.TryParseHex(color, out mc))
            mc = System.Windows.Media.Color.FromRgb(255, 255, 255);
        var b = new SolidColorBrush(mc);
        b.Freeze();
        return b;
    }

    private static IEnumerable<PropertyRow> DecalProperties(Viewport.SceneObject o)
    {
        // Legacy single decal (pre-multi): keep editing it in place until the
        // user adds another, which migrates it into the list.
        if (o.Decals.Count == 0 && !string.IsNullOrWhiteSpace(o.DecalImage))
        {
            yield return new PropertyRow { Category = "Decal", Name = "Image", Type = "file", Value = o.DecalImage,
                Thumbnail = LoadThumbnail(o.DecalImage),
                Description = "Decal image file. Click … to replace." };
            yield return new PropertyRow
            {
                Category = "Decal", Name = "Face", Type = "enum", Value = o.DecalFace,
                Choices = new[] { "Front", "Back", "Left", "Right", "Top", "Bottom" },
                Description = "Which part face shows the decal.",
            };
            yield return new PropertyRow { Category = "Decal", Name = "Image Transparency", Type = "number",
                Value = o.DecalTransparency.ToString("0.00", CultureInfo.InvariantCulture),
                Description = "0 = opaque, 1 = invisible. Drag the slider or type 0-1." };
            yield return new PropertyRow { Category = "Decal", Name = "Image Blur", Type = "number",
                Value = o.DecalBlur.ToString("0.00", CultureInfo.InvariantCulture),
                Description = "Softens the decal (9-tap Gaussian). 0 = sharp, 1 = max blur." };
        }
        else
        {
            for (int i = 0; i < o.Decals.Count; i++)
            {
                var d = o.Decals[i];
                string cat = $"Decal {i + 1}";
                yield return new PropertyRow { Category = cat, Name = "Image", Type = "file", Value = d.Image,
                    DecalIndex = i, Thumbnail = LoadThumbnail(d.Image),
                    Description = $"Decal {i + 1} image file. Click … to replace." };
                yield return new PropertyRow
                {
                    Category = cat, Name = "Face", Type = "enum", Value = d.Face, DecalIndex = i,
                    Choices = new[] { "Front", "Back", "Left", "Right", "Top", "Bottom" },
                    Description = $"Which part face shows decal {i + 1}.",
                };
                yield return new PropertyRow { Category = cat, Name = "Image Transparency", Type = "number",
                    Value = d.Transparency.ToString("0.00", CultureInfo.InvariantCulture), DecalIndex = i,
                    Description = "0 = opaque, 1 = invisible. Drag the slider or type 0-1." };
                yield return new PropertyRow { Category = cat, Name = "Image Blur", Type = "number",
                    Value = d.Blur.ToString("0.00", CultureInfo.InvariantCulture), DecalIndex = i,
                    Description = "Softens the decal (9-tap Gaussian). 0 = sharp, 1 = max blur." };
                yield return new PropertyRow { Category = cat, Name = "Offset", Value = OffsetValue(d.OffsetX, d.OffsetY),
                    DecalIndex = i, Description = $"Decal {i + 1} center on the face, x right / y up (-1 to 1). 0, 0 = centered." };
                yield return new PropertyRow { Category = cat, Name = "Scale", Type = "number",
                    Value = d.Scale.ToString("0.00", CultureInfo.InvariantCulture), DecalIndex = i,
                    Description = $"Fraction of the face decal {i + 1} covers. 1 = full face." };
                yield return new PropertyRow { Category = cat, Name = "Remove", Type = "action",
                    Value = "Remove", DecalIndex = i,
                    Description = $"Remove decal {i + 1} from this part." };
            }
        }
        if (o.Decals.Count < Viewport.SceneObject.MaxDecals)
            yield return new PropertyRow { Category = "Decal", Name = "Add decal", Type = "action",
                Value = o.Decals.Count == 0 && string.IsNullOrWhiteSpace(o.DecalImage) ? "+ Add decal" : "+ Add another",
                Description = $"Add an image decal (up to {Viewport.SceneObject.MaxDecals} per part, any face)." };
    }

    private static string OffsetValue(float x, float y) =>
        string.Format(CultureInfo.InvariantCulture, "{0:0.00}, {1:0.00}", x, y);

    private static bool TryV2(string text, out float x, out float y)
    {
        x = y = 0;
        var parts = text.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 2) return false;
        return TryFloat(parts[0], out x) && TryFloat(parts[1], out y);
    }

    private static string PosValue(Viewport.SceneObject o) =>
        string.Format(CultureInfo.InvariantCulture, "{0:0.0}, {1:0.0}, {2:0.0}", o.Position.X, o.Position.Y, o.Position.Z);
    private static string SizeValue(Viewport.SceneObject o) =>
        string.Format(CultureInfo.InvariantCulture, "{0:0.0}, {1:0.0}, {2:0.0}", o.Size.X, o.Size.Y, o.Size.Z);
    private static string RotValue(Viewport.SceneObject o) =>
        string.Format(CultureInfo.InvariantCulture, "{0:0}, {1:0}, {2:0}°", o.Rotation.X, o.Rotation.Y, o.Rotation.Z);
    private static string ColorValue(Viewport.SceneObject o) =>
        $"{ToByte(o.Color.R)}, {ToByte(o.Color.G)}, {ToByte(o.Color.B)}";

    private static byte ToByte(float v) => (byte)Math.Clamp(v * 255f, 0f, 255f);

    private static float Component(Vector3 v, int axis) =>
        axis == 0 ? v.X : axis == 1 ? v.Y : v.Z;

    private float SnapScaleCoordinate(float coordinate)
    {
        if (SnapCheck.IsChecked != true || _dragAxis < 0) return coordinate;
        float baseSize = Component(_dragSize, _dragAxis);
        float size = Math.Max(baseSize + (coordinate - _dragCoord0) * _dragSign, 0.05f);
        size = MathF.Max(0.5f, MathF.Round(size * 2f) / 2f);
        return _dragCoord0 + (size - baseSize) * _dragSign;
    }

    private static void SetComponent(ref Vector3 v, int axis, float value)
    {
        if (axis == 0) v.X = value;
        else if (axis == 1) v.Y = value;
        else v.Z = value;
    }

    /// <summary>
    /// Apply one eased scale step toward coordinate s (grab-space). The face opposite
    /// the grab stays put, so the grabbed face tracks the eased value exactly.
    /// </summary>
    private void ApplyScaleSize(float s)
    {
        if (_scene.Selected == null || _dragAxis < 0) return;
        float v = Math.Max(Component(_dragSize, _dragAxis) + (s - _dragCoord0) * _dragSign, 0.05f);
        if (SnapCheck.IsChecked == true) v = MathF.Max(0.5f, MathF.Round(v * 2f) / 2f);
        var sz = _scene.Selected.Size;
        float old = Component(sz, _dragAxis);
        SetComponent(ref sz, _dragAxis, Math.Max(v, 0.05f));
        _scene.Selected.Size = sz;
        float grown = Component(sz, _dragAxis) - old;
        if (grown != 0)
            _scene.Selected.Position += _scene.GizmoAxis(_dragAxis) * (_dragSign * grown / 2f);
    }

    private void Search_GotFocus(object sender, RoutedEventArgs e)
    {
        if (sender is not TextBox t) return;
        string hint = ReferenceEquals(sender, PropertiesFilter) ? "Filter" : "Search";
        if (t.Text == hint) t.Text = "";
    }

    private void Search_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is not TextBox t || !string.IsNullOrWhiteSpace(t.Text)) return;
        t.Text = ReferenceEquals(sender, PropertiesFilter) ? "Filter" : "Search";
    }

    // ---------- helpers ----------

    private void Log(string msg)
    {
        OutputBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}\n");
        if (OutputBox.LineCount > 800) // bound long sessions: drop oldest 200 lines
            OutputBox.Text = OutputBox.Text.Substring(OutputBox.GetCharacterIndexFromLineIndex(200));
        OutputBox.ScrollToEnd();
    }

    private int CountObjects()
    {
        int count = 0;
        if (ExplorerTree.ItemsSource is System.Collections.IEnumerable roots)
            foreach (SceneNode r in roots)
                count += 1 + CountChildren(r);
        return count;
    }

    private static int CountChildren(SceneNode n)
    {
        int c = n.Children.Count;
        foreach (var k in n.Children) c += CountChildren(k);
        return c;
    }

    private static List<PropertyRow> DefaultProperties(string name, string type = "Part") => new()
    {
        new PropertyRow { Category = "General", Name = "Name", Value = name,
            Description = "Service or container name (display only)." },
        new PropertyRow { Category = "General", Name = "Class", Value = type, Type = "readonly",
            Description = "Built-in class. Select a Part to edit live properties." },
        new PropertyRow { Category = "Transform", Name = "Position", Value = "0, 0, 0", Type = "vector",
            Description = "Select a Part to edit its transform." },
        new PropertyRow { Category = "Transform", Name = "Size", Value = "2, 2, 2", Type = "vector",
            Description = "Select a Part to edit its size." },
        new PropertyRow { Category = "Transform", Name = "Rotation", Value = "0, 0, 0", Type = "vector",
            Description = "Select a Part to edit its rotation." },
        new PropertyRow { Category = "Appearance", Name = "Color", Value = "38, 128, 242", Type = "color",
            Swatch = new SolidColorBrush(System.Windows.Media.Color.FromRgb(38, 128, 242)),
            Description = "Select a Part to edit its color." },
        new PropertyRow { Category = "Appearance", Name = "Material", Value = "Plastic", Type = "readonly",
            Description = "Select a Part to change its material." },
        new PropertyRow { Category = "Appearance", Name = "Transparency", Value = "0.00", Type = "readonly",
            Description = "Select a Part to edit its transparency." },
        new PropertyRow { Category = "Appearance", Name = "Reflectance", Value = "0.00", Type = "readonly",
            Description = "Select a Part to edit its reflection." },
        new PropertyRow { Category = "Appearance", Name = "CastShadow", Value = "True", Type = "readonly",
            Description = "Select a Part to toggle its shadow casting." },
        new PropertyRow { Category = "Behavior", Name = "Anchored", Type = "bool", Value = "True",
            Description = "Display only for services. Parts use this to freeze physics." },
        new PropertyRow { Category = "Behavior", Name = "Mass", Value = "1.00", Type = "readonly",
            Description = "Select a Part to edit how heavy it is." },
        new PropertyRow { Category = "Behavior", Name = "CanCollide", Value = "True", Type = "readonly",
            Description = "Select a Part to toggle ghost collision." },
    };
}
