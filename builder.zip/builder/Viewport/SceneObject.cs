using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using OpenTK.Mathematics;

namespace builder.Viewport;

/// <summary>Installed system font families for text layers (cached, alphabetical).</summary>
public static class TextFonts
{
    private static IReadOnlyList<string>? _names;

    public static IReadOnlyList<string> Names => _names ??=
        FontFamily.Families.Select(f => f.Name)
            .OrderBy(n => n, StringComparer.OrdinalIgnoreCase).ToList();

    public static bool Exists(string? name) =>
        !string.IsNullOrWhiteSpace(name) &&
        Names.Any(n => n.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase));

    public static string OrFallback(string? name, string fallback = "Arial") =>
        Exists(name) ? name!.Trim() : Exists(fallback) ? fallback : Names.FirstOrDefault() ?? fallback;
}

public sealed class DecalLayer
{
    public string Image { get; set; } = "";
    public string Face { get; set; } = "Front";
    public float Transparency { get; set; }
    public float Blur { get; set; }
    /// <summary>Center offset on the face, fractions (+x right, +y up). 0,0 = centered.</summary>
    public float OffsetX { get; set; }
    public float OffsetY { get; set; }
    /// <summary>Fraction of the face covered. 1 = full face.</summary>
    public float Scale { get; set; } = 1f;
    public DecalLayer Clone() => new()
    {
        Image = Image, Face = Face, Transparency = Transparency, Blur = Blur,
        OffsetX = OffsetX, OffsetY = OffsetY, Scale = Scale,
    };
}

/// <summary>Text drawn on a part face (decal sibling). Font is a system family name.</summary>
public sealed class TextLayer
{
    public string Text { get; set; } = "Text";
    public string Face { get; set; } = "Front";
    public string Font { get; set; } = "Arial";
    public float Size { get; set; } = 48;
    public string Color { get; set; } = "255, 255, 255";
    public float Transparency { get; set; }
    public float Blur { get; set; }
    /// <summary>Center offset on the face, fractions (+x right, +y up). 0,0 = centered.</summary>
    public float OffsetX { get; set; }
    public float OffsetY { get; set; }
    /// <summary>Fraction of the face covered. 1 = full face.</summary>
    public float Scale { get; set; } = 1f;
    public TextLayer Clone() => new()
    {
        Text = Text, Face = Face, Font = Font, Size = Size,
        Color = Color, Transparency = Transparency, Blur = Blur,
        OffsetX = OffsetX, OffsetY = OffsetY, Scale = Scale,
    };
}

/// <summary>A single part in the 3D scene. Mesh is shared per shape.</summary>
public sealed class SceneObject
{
    public string Name { get; set; } = "Part";
    public ShapeKind Shape { get; set; } = ShapeKind.Block;
    public Vector3 Position { get; set; } = Vector3.Zero;
    public Vector3 Size { get; set; } = new(2, 2, 2);

    /// <summary>Orientation as XYZ euler degrees. Source of truth in edit mode.</summary>
    public Vector3 Rotation { get; set; } = Vector3.Zero;
    public Color4 Color { get; set; } = new(0.25f, 0.55f, 0.95f, 1f);
    public MaterialKind Material { get; set; } = MaterialKind.Plastic;

    /// <summary>Extra transparency 0-1 on top of the material (0 = as the material says).</summary>
    public float Transparency { get; set; }

    /// <summary>Faked sky/sun reflection 0-1 (no env map; gradient + glint).</summary>
    public float Reflectance { get; set; }

    /// <summary>Off = invisible to the shadow map (still receives).</summary>
    public bool CastShadow { get; set; } = true;

    /// <summary>Roblox-style anchor: physics treats it as immovable (static in play mode).</summary>
    public bool Anchored { get; set; }

    /// <summary>Off = ghost: renders and selects, but never collides.</summary>
    public bool CanCollide { get; set; } = true;

    /// <summary>Transient avatar face panel (managed by Play mode, never saved).</summary>
    public bool IsAvatarFace { get; set; }

    /// <summary>Body mass for Play mode (heavier parts push harder; all fall the same).</summary>
    public float Mass { get; set; } = 1f;

    /// <summary>Spawn point: the avatar starts here on Play; multiples allowed (first wins).</summary>
    public bool IsSpawn { get; set; }
    public string? DecalImage { get; set; }
    public float DecalTransparency { get; set; }
    public float DecalBlur { get; set; }
    public string DecalFace { get; set; } = "Front";
    public List<DecalLayer> Decals { get; } = new();
    public List<TextLayer> Texts { get; } = new();

    /// <summary>Max decals / texts per part (bounds overdraw + Properties rows).</summary>
    public const int MaxDecals = 6;
    public const int MaxTexts = 6;

    /// <summary>Move the legacy single decal into <see cref="Decals"/> (once). No-op otherwise.</summary>
    public void MigrateSingleToList()
    {
        if (string.IsNullOrWhiteSpace(DecalImage)) return;
        if (Decals.Count >= MaxDecals) { DecalImage = null; return; }
        Decals.Add(new DecalLayer
        {
            Image = DecalImage,
            Face = string.IsNullOrWhiteSpace(DecalFace) ? "Front" : DecalFace,
            Transparency = DecalTransparency,
            Blur = DecalBlur,
        });
        DecalImage = null;
        DecalTransparency = 0;
        DecalBlur = 0;
        DecalFace = "Front";
    }

    /// <summary>Full orientation. Edit mode composes it from Rotation; play mode reads it from physics.</summary>
    public Quaternion Orientation { get; set; } = Quaternion.Identity;

    /// <summary>Rebuild Orientation from the editor euler (edit mode only).</summary>
    public void ComposeOrientation()
    {
        Orientation = EulerToQuat(Rotation);
    }

    /// <summary>
    /// Euler degrees -&gt; quaternion, yaw-pitch-roll (Y, then X, then Z intrinsic).
    /// Closed-form Hamilton product; matches FromAxisAngle on every single axis.
    /// </summary>
    public static Quaternion EulerToQuat(Vector3 eulerDeg)
    {
        float hx = MathHelper.DegreesToRadians(eulerDeg.X) / 2f;
        float hy = MathHelper.DegreesToRadians(eulerDeg.Y) / 2f;
        float hz = MathHelper.DegreesToRadians(eulerDeg.Z) / 2f;
        float cx = MathF.Cos(hx), sx = MathF.Sin(hx);
        float cy = MathF.Cos(hy), sy = MathF.Sin(hy);
        float cz = MathF.Cos(hz), sz = MathF.Sin(hz);
        return new Quaternion(
            cy * sx * cz + sy * cx * sz,
            sy * cx * cz - cy * sx * sz,
            cy * cx * sz - sy * sx * cz,
            cy * cx * cz + sy * sx * sz);
    }

    /// <summary>
    /// Quaternion -&gt; euler degrees, exact inverse of <see cref="EulerToQuat"/>
    /// (standard YXZ extraction on the Hamilton rotation matrix).
    /// </summary>
    public static Vector3 QuatToEuler(Quaternion q)
    {
        float xx = q.X * q.X, yy = q.Y * q.Y, zz = q.Z * q.Z;
        float xy = q.X * q.Y, xz = q.X * q.Z, yz = q.Y * q.Z;
        float wx = q.W * q.X, wy = q.W * q.Y, wz = q.W * q.Z;
        float r02 = 2f * (xz + wy);
        float r12 = 2f * (yz - wx);
        float r22 = 1f - 2f * (xx + yy);
        float r01 = 2f * (xy - wz);
        float r00 = 1f - 2f * (yy + zz);
        float y = MathF.Asin(Math.Clamp(r02, -1f, 1f));
        float x, z;
        if (MathF.Abs(r02) < 0.99999f)
        {
            x = MathF.Atan2(-r12, r22);
            z = MathF.Atan2(-r01, r00);
        }
        else // gimbal lock: fold everything into roll
        {
            x = 0;
            z = MathF.Atan2(2f * (xy + wz), 1f - 2f * (xx + zz));
        }
        const float toDeg = 180f / MathF.PI;
        return new Vector3(x * toDeg, y * toDeg, z * toDeg);
    }

    public SceneObject Clone(string name)
    {
        var copy = new SceneObject
        {
            Name = name,
            Shape = Shape,
            Position = Position,
            Size = Size,
            Rotation = Rotation,
            Color = Color,
            Material = Material,
            Transparency = Transparency,
            Reflectance = Reflectance,
            CastShadow = CastShadow,
            Anchored = Anchored,
            IsSpawn = IsSpawn,
            Mass = Mass,
            CanCollide = CanCollide,
            IsAvatarFace = IsAvatarFace,
            DecalImage = DecalImage,
            DecalTransparency = DecalTransparency,
            DecalBlur = DecalBlur,
            DecalFace = DecalFace,
            Orientation = Orientation,
        };
        foreach (var decal in Decals) copy.Decals.Add(decal.Clone());
        foreach (var text in Texts) copy.Texts.Add(text.Clone());
        return copy;
    }

    public (Vector3 Position, Quaternion Orientation, Vector3 Rotation) Snapshot() =>
        (Position, Orientation, Rotation);

    public void Restore((Vector3 Position, Quaternion Orientation, Vector3 Rotation) snap)
    {
        Position = snap.Position;
        Orientation = snap.Orientation;
        Rotation = snap.Rotation;
    }
}
