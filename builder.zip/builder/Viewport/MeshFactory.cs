using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using static builder.Viewport.StudioScene;

namespace builder.Viewport;

/// <summary>Available part meshes. All unit-sized, centered on the origin.</summary>
public enum ShapeKind
{
    Block,
    Ball,
    Cylinder,
    Wedge,
    Cone,
    Torus,
    Capsule,
}

/// <summary>Procedural primitive meshes (positions + flat normals). Windings are CCW-outside.</summary>
internal static class MeshFactory
{
    private static void Tri(List<Vertex> dst, Vector3 a, Vector3 b, Vector3 c, Vector3 n)
    {
        dst.Add(new Vertex(a, n));
        dst.Add(new Vertex(b, n));
        dst.Add(new Vertex(c, n));
    }

    private static void Quad(List<Vertex> dst, Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 n)
    {
        Tri(dst, a, b, c, n);
        Tri(dst, a, c, d, n);
    }

    public static Vertex[] Block()
    {
        var tris = new List<Vertex>();
        Vector3[] p =
        {
            new(-0.5f, -0.5f, -0.5f), new(0.5f, -0.5f, -0.5f), new(0.5f, 0.5f, -0.5f), new(-0.5f, 0.5f, -0.5f),
            new(-0.5f, -0.5f,  0.5f), new(0.5f, -0.5f,  0.5f), new(0.5f, 0.5f,  0.5f), new(-0.5f, 0.5f,  0.5f),
        };
        Quad(tris, p[4], p[5], p[6], p[7], Vector3.UnitZ);
        Quad(tris, p[1], p[0], p[3], p[2], -Vector3.UnitZ);
        Quad(tris, p[0], p[4], p[7], p[3], -Vector3.UnitX);
        Quad(tris, p[5], p[1], p[2], p[6], Vector3.UnitX);
        Quad(tris, p[7], p[6], p[2], p[3], Vector3.UnitY);
        Quad(tris, p[0], p[1], p[5], p[4], -Vector3.UnitY);
        return tris.ToArray();
    }

    public static Vertex[] Sphere(int lat = 32, int lon = 48)
    {
        var tris = new List<Vertex>();
        Vector3 P(int i, int j)
        {
            float theta = i / (float)lat * MathF.PI;
            float phi = j / (float)lon * MathF.PI * 2f;
            float st = MathF.Sin(theta);
            // Unit primitives span ±0.5 (direction matters, the shader normalizes).
            return new Vector3(st * MathF.Cos(phi), MathF.Cos(theta), st * MathF.Sin(phi)) * 0.5f;
        }
        for (int i = 0; i < lat; i++)
        for (int j = 0; j < lon; j++)
        {
            var p00 = P(i, j); var p10 = P(i + 1, j);
            var p01 = P(i, j + 1); var p11 = P(i + 1, j + 1);
            Tri(tris, p00, p11, p10, p00); // normals = unit positions
            Tri(tris, p00, p01, p11, p01);
        }
        return tris.ToArray();
    }

    public static Vertex[] Cylinder(int seg = 32)
    {
        const float r = 0.5f;
        var tris = new List<Vertex>();
        Vector3 Ring(float a, float y) => new(r * MathF.Cos(a), y, r * MathF.Sin(a));
        Vector3 Rad(float a) => new(MathF.Cos(a), 0, MathF.Sin(a));
        for (int k = 0; k < seg; k++)
        {
            float a0 = k / (float)seg * MathF.PI * 2f;
            float a1 = (k + 1) / (float)seg * MathF.PI * 2f;
            var b0 = Ring(a0, -0.5f); var b1 = Ring(a1, -0.5f);
            var t0 = Ring(a0, 0.5f); var t1 = Ring(a1, 0.5f);
            var n0 = Rad(a0); var n1 = Rad(a1);
            // Smooth sides: per-vertex radial normals so highlights don't facet.
            tris.Add(new Vertex(b0, n0)); tris.Add(new Vertex(t1, n1)); tris.Add(new Vertex(b1, n1));
            tris.Add(new Vertex(b0, n0)); tris.Add(new Vertex(t0, n0)); tris.Add(new Vertex(t1, n1));
            Tri(tris, new Vector3(0, 0.5f, 0), t1, t0, Vector3.UnitY);   // top cap
            Tri(tris, new Vector3(0, -0.5f, 0), b0, b1, -Vector3.UnitY); // bottom cap
        }
        return tris.ToArray();
    }

    public static Vertex[] Wedge()
    {
        // Right triangular prism: full square base, slopes from the top-back
        // edge (y=+.5, z=-.5) down to the bottom-front edge (y=-.5, z=+.5).
        var tris = new List<Vertex>();
        var b0 = new Vector3(-0.5f, -0.5f, -0.5f); var b1 = new Vector3(0.5f, -0.5f, -0.5f);
        var b2 = new Vector3(0.5f, -0.5f, 0.5f); var b3 = new Vector3(-0.5f, -0.5f, 0.5f);
        var t0 = new Vector3(-0.5f, 0.5f, -0.5f); var t1 = new Vector3(0.5f, 0.5f, -0.5f);
        var slopeN = Vector3.Normalize(new Vector3(0, 1, 1));
        Quad(tris, b0, b1, b2, b3, -Vector3.UnitY); // bottom
        Tri(tris, b0, t1, b1, -Vector3.UnitZ);      // back
        Tri(tris, b0, t0, t1, -Vector3.UnitZ);
        Tri(tris, b0, b3, t0, -Vector3.UnitX);      // left triangle
        Tri(tris, b1, t1, b2, Vector3.UnitX);       // right triangle
        Tri(tris, t0, b2, t1, slopeN);              // slope
        Tri(tris, t0, b3, b2, slopeN);
        return tris.ToArray();
    }

    public static Vertex[] Cone(int seg = 32)
    {
        const float r = 0.5f;
        var tris = new List<Vertex>();
        var tip = new Vector3(0, 0.5f, 0);
        var bc = new Vector3(0, -0.5f, 0);
        for (int k = 0; k < seg; k++)
        {
            float a0 = k / (float)seg * MathF.PI * 2f;
            float a1 = (k + 1) / (float)seg * MathF.PI * 2f;
            float am = (a0 + a1) / 2f;
            var p0 = new Vector3(r * MathF.Cos(a0), -0.5f, r * MathF.Sin(a0));
            var p1 = new Vector3(r * MathF.Cos(a1), -0.5f, r * MathF.Sin(a1));
            var n = Vector3.Normalize(new Vector3(MathF.Cos(am), 0.5f, MathF.Sin(am)));
            Tri(tris, tip, p1, p0, n);
            Tri(tris, bc, p0, p1, -Vector3.UnitY);
        }
        return tris.ToArray();
    }

    public static Vertex[] Torus(float R = 0.32f, float r = 0.18f, int rings = 36, int sides = 24)
    {
        var tris = new List<Vertex>();
        Vector3 P(int i, int j)
        {
            float u = i / (float)rings * MathF.PI * 2f;
            float v = j / (float)sides * MathF.PI * 2f;
            float cu = MathF.Cos(u), su = MathF.Sin(u);
            float cv = MathF.Cos(v), sv = MathF.Sin(v);
            return new Vector3((R + r * cv) * cu, r * sv, (R + r * cv) * su);
        }
        Vector3 Nrm(int i, int j)
        {
            float u = i / (float)rings * MathF.PI * 2f;
            float v = j / (float)sides * MathF.PI * 2f;
            return new Vector3(MathF.Cos(v) * MathF.Cos(u), MathF.Sin(v), MathF.Cos(v) * MathF.Sin(u));
        }
        for (int i = 0; i < rings; i++)
        for (int j = 0; j < sides; j++)
        {
            var a = P(i, j); var b = P(i + 1, j); var c = P(i + 1, j + 1); var d = P(i, j + 1);
            var na = Nrm(i, j); var nb = Nrm(i + 1, j); var nc = Nrm(i + 1, j + 1); var nd = Nrm(i, j + 1);
            tris.Add(new Vertex(a, na)); tris.Add(new Vertex(c, nc)); tris.Add(new Vertex(b, nb));
            tris.Add(new Vertex(a, na)); tris.Add(new Vertex(d, nd)); tris.Add(new Vertex(c, nc));
        }
        return tris.ToArray();
    }

    public static Vertex[] Capsule(int seg = 24, int capRings = 12)
    {
        // Pill fitting the unit box: cylinder midsection (|y| <= .25, r = .25)
        // with hemispherical caps. Seam normals match, so shading stays smooth.
        const float r = 0.25f, hy = 0.25f;
        var tris = new List<Vertex>();
        for (int k = 0; k < seg; k++)
        {
            float a0 = k / (float)seg * MathF.PI * 2f;
            float a1 = (k + 1) / (float)seg * MathF.PI * 2f;
            var b0 = new Vector3(r * MathF.Cos(a0), -hy, r * MathF.Sin(a0));
            var b1 = new Vector3(r * MathF.Cos(a1), -hy, r * MathF.Sin(a1));
            var t0 = new Vector3(r * MathF.Cos(a0), hy, r * MathF.Sin(a0));
            var t1 = new Vector3(r * MathF.Cos(a1), hy, r * MathF.Sin(a1));
            var n0 = new Vector3(MathF.Cos(a0), 0, MathF.Sin(a0));
            var n1 = new Vector3(MathF.Cos(a1), 0, MathF.Sin(a1));
            tris.Add(new Vertex(b0, n0)); tris.Add(new Vertex(t1, n1)); tris.Add(new Vertex(b1, n1));
            tris.Add(new Vertex(b0, n0)); tris.Add(new Vertex(t0, n0)); tris.Add(new Vertex(t1, n1));
        }
        Vector3 TopCap(int i, int j, out Vector3 n)
        {
            float p = i / (float)capRings * MathF.PI / 2f;
            float a = j / (float)seg * MathF.PI * 2f;
            float sp = MathF.Sin(p), cp = MathF.Cos(p);
            n = new Vector3(sp * MathF.Cos(a), cp, sp * MathF.Sin(a));
            return new Vector3(r * n.X, hy + r * n.Y, r * n.Z);
        }
        Vector3 BotCap(int i, int j, out Vector3 n)
        {
            float q = i / (float)capRings * MathF.PI / 2f;
            float a = j / (float)seg * MathF.PI * 2f;
            float sq = MathF.Sin(q), cq = MathF.Cos(q);
            n = new Vector3(sq * MathF.Cos(a), -cq, sq * MathF.Sin(a));
            return new Vector3(r * n.X, -hy + r * n.Y, r * n.Z);
        }
        for (int i = 0; i < capRings; i++)
        for (int j = 0; j < seg; j++)
        {
            var p00 = TopCap(i, j, out var n00); var p10 = TopCap(i + 1, j, out var n10);
            var p01 = TopCap(i, j + 1, out var n01); var p11 = TopCap(i + 1, j + 1, out var n11);
            tris.Add(new Vertex(p00, n00)); tris.Add(new Vertex(p11, n11)); tris.Add(new Vertex(p10, n10));
            tris.Add(new Vertex(p00, n00)); tris.Add(new Vertex(p01, n01)); tris.Add(new Vertex(p11, n11));

            var q00 = BotCap(i, j, out var m00); var q10 = BotCap(i + 1, j, out var m10);
            var q01 = BotCap(i, j + 1, out var m01); var q11 = BotCap(i + 1, j + 1, out var m11);
            tris.Add(new Vertex(q00, m00)); tris.Add(new Vertex(q10, m10)); tris.Add(new Vertex(q11, m11));
            tris.Add(new Vertex(q00, m00)); tris.Add(new Vertex(q11, m11)); tris.Add(new Vertex(q01, m01));
        }
        return tris.ToArray();
    }

    public static Vertex[] For(ShapeKind shape) => shape switch
    {
        ShapeKind.Ball => Sphere(),
        ShapeKind.Cylinder => Cylinder(),
        ShapeKind.Wedge => Wedge(),
        ShapeKind.Cone => Cone(),
        ShapeKind.Torus => Torus(),
        ShapeKind.Capsule => Capsule(),
        _ => Block(),
    };
}
